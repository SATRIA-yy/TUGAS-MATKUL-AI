# Script to assemble the self-contained index.html dashboard
import json

with open('dataset.min.json', 'r', encoding='utf-8') as f:
    dataset_json = f.read()

html_content = f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Executive Sales & Profit Dashboard | Enterprise Analytics</title>
  <meta name="description" content="Executive-grade interactive business intelligence dashboard for enterprise sales, profitability, operational health, and strategic growth analysis.">
  
  <!-- Google Fonts: Inter -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  
  <!-- Chart.js CDN -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>

  <style>
    /* ==========================================================================
       DESIGN SYSTEM & CSS VARIABLES
       ========================================================================== */
    :root {{
      /* Light Theme Colors (Default) */
      --bg-body: #f1f5f9;
      --bg-sidebar: #ffffff;
      --bg-card: #ffffff;
      --bg-card-subtle: #f8fafc;
      --bg-input: #ffffff;
      --bg-hover: #f1f5f9;
      --bg-active: #e2e8f0;
      
      --border-color: #e2e8f0;
      --border-subtle: #edf2f7;
      --border-focus: #0284c7;
      
      --text-primary: #0f172a;    /* Deep navy */
      --text-secondary: #475569;  /* Muted slate */
      --text-muted: #94a3b8;      /* Light slate */
      --text-inverse: #ffffff;
      
      /* Enterprise Accents */
      --accent-primary: #0284c7;   /* Sky/Teal-Blue primary */
      --accent-hover: #0369a1;
      --accent-subtle: #e0f2fe;
      --accent-teal: #0d9488;
      --accent-teal-subtle: #ccfbf1;
      
      /* Semantic Status Colors */
      --success: #10b981;          /* Emerald */
      --success-subtle: #d1fae5;
      --success-text: #065f46;
      
      --danger: #ef4444;           /* Rose/Red */
      --danger-subtle: #fee2e2;
      --danger-text: #991b1b;
      
      --warning: #f59e0b;          /* Amber */
      --warning-subtle: #fef3c7;
      --warning-text: #92400e;
      
      --info: #3b82f6;             /* Blue */
      --info-subtle: #dbeafe;
      --info-text: #1e40af;
      
      /* Shadows */
      --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
      --shadow-sm: 0 1px 3px 0 rgba(15, 23, 42, 0.08), 0 1px 2px -1px rgba(15, 23, 42, 0.04);
      --shadow-md: 0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.05);
      --shadow-lg: 0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04);
      
      /* Layout & Spacing */
      --sidebar-width: 320px;
      --header-height: 76px;
      --radius-sm: 6px;
      --radius-md: 10px;
      --radius-lg: 14px;
      --radius-full: 9999px;
      
      /* Fonts */
      --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      --font-mono: 'JetBrains Mono', monospace;
    }}

    [data-theme="dark"] {{
      --bg-body: #090d16;
      --bg-sidebar: #0f172a;
      --bg-card: #131c2e;
      --bg-card-subtle: #1a2438;
      --bg-input: #1a2438;
      --bg-hover: #222f47;
      --bg-active: #2a3b59;
      
      --border-color: #222f47;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
      
      --text-primary: #f8fafc;
      --text-secondary: #cbd5e1;
      --text-muted: #64748b;
      --text-inverse: #090d16;
      
      --accent-primary: #38bdf8;
      --accent-hover: #7dd3fc;
      --accent-subtle: rgba(56, 189, 248, 0.15);
      --accent-teal: #2dd4bf;
      --accent-teal-subtle: rgba(45, 212, 191, 0.15);
      
      --success: #34d399;
      --success-subtle: rgba(52, 211, 153, 0.15);
      --success-text: #6ee7b7;
      
      --danger: #f87171;
      --danger-subtle: rgba(248, 113, 113, 0.15);
      --danger-text: #fca5a5;
      
      --warning: #fbbf24;
      --warning-subtle: rgba(251, 191, 36, 0.15);
      --warning-text: #fde68a;
      
      --info: #60a5fa;
      --info-subtle: rgba(96, 165, 250, 0.15);
      --info-text: #93c5fd;
      
      --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
      --shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.4), 0 1px 2px -1px rgba(0, 0, 0, 0.3);
      --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -2px rgba(0, 0, 0, 0.3);
      --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -4px rgba(0, 0, 0, 0.4);
    }}

    /* Reset & Base */
    *, *::before, *::after {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    
    html {{
      scroll-behavior: smooth;
      font-size: 14px;
    }}
    
    body {{
      font-family: var(--font-sans);
      background-color: var(--bg-body);
      color: var(--text-primary);
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      display: flex;
      min-height: 100vh;
      overflow-x: hidden;
      transition: background-color 0.25s ease, color 0.25s ease;
    }}

    /* ==========================================================================
       SIDEBAR & FILTER CONSOLE
       ========================================================================== */
    .sidebar {{
      width: var(--sidebar-width);
      min-width: var(--sidebar-width);
      background: var(--bg-sidebar);
      border-right: 1px solid var(--border-color);
      display: flex;
      flex-direction: column;
      height: 100vh;
      position: sticky;
      top: 0;
      z-index: 100;
      overflow-y: auto;
      transition: transform 0.3s ease, background 0.25s ease, border-color 0.25s ease;
    }}

    .sidebar::-webkit-scrollbar {{
      width: 5px;
    }}
    .sidebar::-webkit-scrollbar-thumb {{
      background: var(--border-color);
      border-radius: 10px;
    }}

    .sidebar-header {{
      padding: 20px 24px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      gap: 12px;
      background: var(--bg-sidebar);
      position: sticky;
      top: 0;
      z-index: 10;
    }}

    .brand-logo {{
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, #0284c7 0%, #0d9488 100%);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #ffffff;
      box-shadow: 0 4px 10px rgba(2, 132, 199, 0.25);
      flex-shrink: 0;
    }}

    .brand-title {{
      font-size: 1.05rem;
      font-weight: 700;
      color: var(--text-primary);
      letter-spacing: -0.02em;
      line-height: 1.2;
    }}

    .brand-subtitle {{
      font-size: 0.72rem;
      color: var(--text-muted);
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }}

    /* Section Quick Nav */
    .quick-nav {{
      padding: 16px 20px 8px;
      border-bottom: 1px solid var(--border-color);
    }}

    .nav-label {{
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--text-muted);
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }}

    .nav-list {{
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 3px;
    }}

    .nav-item a {{
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 12px;
      border-radius: var(--radius-sm);
      color: var(--text-secondary);
      text-decoration: none;
      font-weight: 500;
      font-size: 0.85rem;
      transition: all 0.15s ease;
    }}

    .nav-item a:hover, .nav-item a.active {{
      background: var(--accent-subtle);
      color: var(--accent-primary);
      font-weight: 600;
    }}

    .nav-item a svg {{
      width: 16px;
      height: 16px;
      opacity: 0.85;
    }}

    /* Filter Groups */
    .filter-section {{
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 20px;
      flex-grow: 1;
    }}

    .filter-header-bar {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: -5px;
    }}

    .filter-count-badge {{
      background: var(--accent-subtle);
      color: var(--accent-primary);
      padding: 2px 8px;
      border-radius: var(--radius-full);
      font-size: 0.72rem;
      font-weight: 700;
    }}

    .btn-reset-filters {{
      background: none;
      border: none;
      color: var(--accent-primary);
      font-size: 0.75rem;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px 8px;
      border-radius: var(--radius-sm);
      transition: background 0.15s ease;
    }}
    .btn-reset-filters:hover {{
      background: var(--accent-subtle);
    }}

    .filter-group {{
      display: flex;
      flex-direction: column;
      gap: 8px;
    }}

    .filter-title {{
      font-size: 0.78rem;
      font-weight: 600;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }}

    .filter-title span.hint {{
      font-size: 0.7rem;
      font-weight: 400;
      color: var(--text-muted);
    }}

    /* Multi-select Pills / Checkboxes */
    .pill-group {{
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }}

    .pill-btn {{
      background: var(--bg-input);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      padding: 5px 10px;
      border-radius: var(--radius-sm);
      font-size: 0.78rem;
      font-weight: 500;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 5px;
      user-select: none;
      transition: all 0.15s ease;
    }}

    .pill-btn:hover {{
      border-color: var(--accent-primary);
      color: var(--accent-primary);
      background: var(--bg-hover);
    }}

    .pill-btn.active {{
      background: var(--accent-primary);
      border-color: var(--accent-primary);
      color: #ffffff;
      font-weight: 600;
      box-shadow: 0 2px 5px rgba(2, 132, 199, 0.25);
    }}

    /* Form Controls */
    .form-control {{
      width: 100%;
      padding: 7px 10px;
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      background: var(--bg-input);
      color: var(--text-primary);
      font-family: inherit;
      font-size: 0.8rem;
      outline: none;
      transition: border-color 0.15s ease;
    }}

    .form-control:focus {{
      border-color: var(--border-focus);
      box-shadow: 0 0 0 2px var(--accent-subtle);
    }}

    .search-wrapper {{
      position: relative;
    }}
    .search-wrapper svg {{
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--text-muted);
      pointer-events: none;
    }}
    .search-wrapper .form-control {{
      padding-left: 32px;
    }}

    .date-range-row {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }}
    .date-input-group label {{
      font-size: 0.68rem;
      color: var(--text-muted);
      margin-bottom: 2px;
      display: block;
      font-weight: 500;
    }}

    /* Sales Person custom select dropdown */
    .custom-select-wrapper {{
      position: relative;
    }}
    .rep-dropdown-list {{
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      max-height: 180px;
      overflow-y: auto;
      z-index: 50;
      box-shadow: var(--shadow-lg);
      margin-top: 4px;
      display: none;
    }}
    .rep-dropdown-list.show {{
      display: block;
    }}
    .rep-item {{
      padding: 6px 12px;
      font-size: 0.78rem;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      color: var(--text-secondary);
      transition: background 0.1s;
    }}
    .rep-item:hover, .rep-item.selected {{
      background: var(--accent-subtle);
      color: var(--accent-primary);
      font-weight: 600;
    }}

    /* Return Status Segmented Control */
    .segmented-control {{
      display: flex;
      background: var(--bg-card-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      padding: 2px;
    }}
    .seg-btn {{
      flex: 1;
      text-align: center;
      padding: 5px 8px;
      border: none;
      background: none;
      font-size: 0.78rem;
      font-weight: 500;
      color: var(--text-secondary);
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.15s ease;
    }}
    .seg-btn.active {{
      background: var(--bg-card);
      color: var(--accent-primary);
      font-weight: 600;
      box-shadow: var(--shadow-xs);
    }}

    /* ==========================================================================
       MAIN CONTENT CONTAINER
       ========================================================================== */
    .main-wrapper {{
      flex: 1;
      display: flex;
      flex-direction: column;
      min-width: 0;
      overflow-y: auto;
      height: 100vh;
    }}

    /* Top Executive Header */
    .main-header {{
      background: var(--bg-card);
      border-bottom: 1px solid var(--border-color);
      padding: 16px 32px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 90;
      box-shadow: var(--shadow-xs);
      transition: background 0.25s ease, border-color 0.25s ease;
    }}

    .header-left {{
      display: flex;
      flex-direction: column;
      gap: 4px;
    }}

    .header-title-row {{
      display: flex;
      align-items: center;
      gap: 12px;
      flex-wrap: wrap;
    }}

    .header-title {{
      font-size: 1.45rem;
      font-weight: 800;
      color: var(--text-primary);
      letter-spacing: -0.02em;
    }}

    .header-badge {{
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 3px 10px;
      border-radius: var(--radius-full);
      font-size: 0.72rem;
      font-weight: 600;
    }}

    .badge-date {{
      background: var(--accent-subtle);
      color: var(--accent-primary);
      border: 1px solid rgba(2, 132, 199, 0.2);
    }}

    .badge-partial-year {{
      background: var(--warning-subtle);
      color: var(--warning-text);
      border: 1px solid rgba(245, 158, 11, 0.3);
    }}

    .header-subtitle {{
      font-size: 0.85rem;
      color: var(--text-secondary);
      display: flex;
      align-items: center;
      gap: 10px;
    }}

    .header-actions {{
      display: flex;
      align-items: center;
      gap: 10px;
    }}

    .btn-header-action {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      padding: 8px 14px;
      border-radius: var(--radius-sm);
      font-size: 0.82rem;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s ease;
    }}

    .btn-header-action:hover {{
      background: var(--bg-hover);
      color: var(--text-primary);
      border-color: var(--border-focus);
    }}

    .btn-mobile-sidebar {{
      display: none;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      color: var(--text-primary);
      padding: 8px 12px;
      border-radius: var(--radius-sm);
      cursor: pointer;
    }}

    /* Active Filter Summary Bar */
    .active-filters-bar {{
      background: var(--bg-card-subtle);
      border-bottom: 1px solid var(--border-color);
      padding: 10px 32px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 0.78rem;
      flex-wrap: wrap;
      gap: 10px;
    }}

    .active-chips-wrap {{
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px;
    }}

    .active-chip {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      color: var(--text-primary);
      padding: 3px 8px;
      border-radius: var(--radius-full);
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 0.73rem;
      font-weight: 500;
    }}
    .active-chip button {{
      background: none;
      border: none;
      color: var(--text-muted);
      cursor: pointer;
      display: flex;
      align-items: center;
      padding: 0;
      font-size: 0.9rem;
    }}
    .active-chip button:hover {{
      color: var(--danger);
    }}

    .filter-data-status {{
      color: var(--text-muted);
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 8px;
    }}
    .filter-data-status strong {{
      color: var(--text-primary);
    }}

    /* Content Area */
    .content-area {{
      padding: 28px 32px 60px;
      display: flex;
      flex-direction: column;
      gap: 28px;
    }}

    /* Section Headings */
    .section-header {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 14px;
    }}

    .section-title {{
      font-size: 1.15rem;
      font-weight: 700;
      color: var(--text-primary);
      letter-spacing: -0.01em;
      display: flex;
      align-items: center;
      gap: 8px;
    }}

    .section-desc {{
      font-size: 0.8rem;
      color: var(--text-muted);
      font-weight: 400;
    }}

    /* ==========================================================================
       KPI CARDS GRID
       ========================================================================== */
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
      gap: 16px;
    }}

    .kpi-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 20px;
      box-shadow: var(--shadow-sm);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      overflow: hidden;
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
    }}

    .kpi-card:hover {{
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
      border-color: var(--border-focus);
    }}

    .kpi-card::before {{
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: var(--card-accent, var(--accent-primary));
    }}

    .kpi-top {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }}

    .kpi-label {{
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--text-secondary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }}

    .kpi-icon-wrap {{
      width: 32px;
      height: 32px;
      border-radius: var(--radius-sm);
      background: var(--icon-bg, var(--accent-subtle));
      color: var(--icon-color, var(--accent-primary));
      display: flex;
      align-items: center;
      justify-content: center;
    }}

    .kpi-value {{
      font-size: 1.85rem;
      font-weight: 800;
      color: var(--text-primary);
      letter-spacing: -0.03em;
      line-height: 1.1;
      margin-bottom: 8px;
      font-variant-numeric: tabular-nums;
    }}

    .kpi-footer {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 0.72rem;
      border-top: 1px solid var(--border-subtle);
      padding-top: 8px;
      margin-top: 4px;
    }}

    .kpi-trend {{
      display: inline-flex;
      align-items: center;
      gap: 3px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: var(--radius-full);
      font-size: 0.7rem;
    }}

    .kpi-trend.positive {{
      background: var(--success-subtle);
      color: var(--success-text);
    }}

    .kpi-trend.negative {{
      background: var(--danger-subtle);
      color: var(--danger-text);
    }}

    .kpi-trend.neutral {{
      background: var(--bg-hover);
      color: var(--text-secondary);
    }}

    .kpi-trend.warning {{
      background: var(--warning-subtle);
      color: var(--warning-text);
    }}

    .kpi-subtext {{
      color: var(--text-muted);
      font-weight: 500;
    }}

    /* Card accent overrides */
    .card-sales {{ --card-accent: #0284c7; --icon-bg: #e0f2fe; --icon-color: #0284c7; }}
    .card-profit {{ --card-accent: #10b981; --icon-bg: #d1fae5; --icon-color: #059669; }}
    .card-margin {{ --card-accent: #0d9488; --icon-bg: #ccfbf1; --icon-color: #0d9488; }}
    .card-orders {{ --card-accent: #6366f1; --icon-bg: #e0e7ff; --icon-color: #4f46e5; }}
    .card-aov {{ --card-accent: #8b5cf6; --icon-bg: #ede9fe; --icon-color: #7c3aed; }}
    .card-return {{ --card-accent: #f43f5e; --icon-bg: #ffe4e6; --icon-color: #e11d48; }}
    .card-customers {{ --card-accent: #d97706; --icon-bg: #fef3c7; --icon-color: #b45309; }}

    /* ==========================================================================
       CHART CARDS & LAYOUTS
       ========================================================================== */
    .chart-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 22px;
      box-shadow: var(--shadow-sm);
      display: flex;
      flex-direction: column;
      gap: 16px;
      position: relative;
      transition: border-color 0.2s ease, background 0.25s ease;
    }}

    .chart-card:hover {{
      border-color: rgba(2, 132, 199, 0.4);
    }}

    .chart-card-header {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
    }}

    .chart-title-group {{
      display: flex;
      flex-direction: column;
      gap: 2px;
    }}

    .chart-title {{
      font-size: 0.98rem;
      font-weight: 700;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
    }}

    .chart-subtitle {{
      font-size: 0.75rem;
      color: var(--text-muted);
    }}

    .chart-controls {{
      display: flex;
      align-items: center;
      gap: 8px;
    }}

    .chart-toggle-btn {{
      background: var(--bg-card-subtle);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      padding: 4px 10px;
      border-radius: var(--radius-sm);
      font-size: 0.74rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
    }}

    .chart-toggle-btn:hover {{
      background: var(--bg-hover);
      color: var(--text-primary);
    }}

    .chart-toggle-btn.active {{
      background: var(--accent-primary);
      border-color: var(--accent-primary);
      color: #ffffff;
    }}

    .chart-container {{
      position: relative;
      width: 100%;
      height: 320px;
    }}

    .chart-container.tall {{
      height: 380px;
    }}

    /* Visual Note Callout under Chart 1 */
    .chart-note-callout {{
      background: var(--bg-card-subtle);
      border-left: 3px solid var(--accent-primary);
      border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
      padding: 8px 14px;
      font-size: 0.74rem;
      color: var(--text-secondary);
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 8px;
    }}

    .chart-note-callout strong {{
      color: var(--text-primary);
    }}

    .stats-inline-chips {{
      display: flex;
      gap: 12px;
    }}
    .stat-chip {{
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 0.72rem;
    }}
    .stat-chip span.val {{
      font-weight: 700;
      color: var(--text-primary);
    }}

    /* 2-Column Chart Grid */
    .grid-2col {{
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
    }}

    /* Donut Legend Custom styling */
    .donut-layout {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      align-items: center;
      gap: 20px;
      height: 100%;
    }}

    .donut-legend-list {{
      display: flex;
      flex-direction: column;
      gap: 10px;
    }}

    .donut-legend-item {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 10px;
      background: var(--bg-card-subtle);
      border-radius: var(--radius-sm);
      font-size: 0.78rem;
    }}

    .legend-indicator {{
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--text-secondary);
      font-weight: 500;
    }}

    .color-dot {{
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }}

    .legend-values {{
      font-weight: 700;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 6px;
    }}

    .legend-pct {{
      color: var(--text-muted);
      font-weight: 500;
      font-size: 0.72rem;
    }}

    /* Scatter correlation banner */
    .scatter-stat-banner {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: var(--accent-subtle);
      border: 1px solid rgba(2, 132, 199, 0.2);
      border-radius: var(--radius-sm);
      padding: 8px 14px;
      font-size: 0.78rem;
    }}
    .correlation-badge {{
      background: var(--accent-primary);
      color: #ffffff;
      padding: 2px 8px;
      border-radius: var(--radius-full);
      font-weight: 700;
      font-family: var(--font-mono);
      font-size: 0.75rem;
    }}

    /* ==========================================================================
       KEY BUSINESS INSIGHTS PANEL
       ========================================================================== */
    .insights-panel {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 24px;
      box-shadow: var(--shadow-sm);
      display: flex;
      flex-direction: column;
      gap: 18px;
    }}

    .insights-header {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
      border-bottom: 1px solid var(--border-color);
      padding-bottom: 14px;
    }}

    .insights-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 16px;
    }}

    .insight-card {{
      background: var(--bg-card-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 16px 18px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      transition: transform 0.15s ease, border-color 0.15s ease;
    }}

    .insight-card:hover {{
      transform: translateY(-2px);
      border-color: var(--border-focus);
    }}

    .insight-top-bar {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }}

    .insight-tag {{
      font-size: 0.68rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      padding: 2px 8px;
      border-radius: var(--radius-full);
    }}

    .tag-growth {{ background: #dbeafe; color: #1e40af; }}
    .tag-risk {{ background: #fee2e2; color: #991b1b; }}
    .tag-opportunity {{ background: #d1fae5; color: #065f46; }}
    .tag-strategy {{ background: #ede9fe; color: #6b21a8; }}
    .tag-ops {{ background: #fef3c7; color: #92400e; }}

    .insight-metric-pill {{
      font-size: 0.72rem;
      font-weight: 700;
      font-family: var(--font-mono);
      color: var(--text-secondary);
    }}

    .insight-title {{
      font-size: 0.92rem;
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1.3;
    }}

    .insight-body {{
      font-size: 0.8rem;
      color: var(--text-secondary);
      line-height: 1.5;
    }}

    .insight-recommendation {{
      background: var(--bg-card);
      border: 1px dashed var(--border-color);
      border-radius: var(--radius-sm);
      padding: 10px 12px;
      font-size: 0.76rem;
      color: var(--text-primary);
      display: flex;
      flex-direction: column;
      gap: 4px;
    }}

    .rec-label {{
      font-size: 0.68rem;
      font-weight: 700;
      color: var(--accent-primary);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }}

    /* ==========================================================================
       TRANSACTION DETAIL TABLE
       ========================================================================== */
    .table-section-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-sm);
      overflow: hidden;
    }}

    .table-header-bar {{
      padding: 18px 22px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
      cursor: pointer;
      user-select: none;
      background: var(--bg-card);
      transition: background 0.15s ease;
    }}

    .table-header-bar:hover {{
      background: var(--bg-card-subtle);
    }}

    .table-collapse-trigger {{
      display: flex;
      align-items: center;
      gap: 10px;
    }}

    .table-collapse-icon {{
      transition: transform 0.2s ease;
      color: var(--text-muted);
    }}

    .table-collapse-icon.collapsed {{
      transform: rotate(-90deg);
    }}

    .table-controls-wrap {{
      padding: 14px 22px;
      background: var(--bg-card-subtle);
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
    }}

    .table-search-box {{
      max-width: 300px;
      flex: 1;
    }}

    .table-export-btn {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      color: var(--text-secondary);
      padding: 6px 12px;
      border-radius: var(--radius-sm);
      font-size: 0.78rem;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s ease;
    }}

    .table-export-btn:hover {{
      background: var(--accent-subtle);
      color: var(--accent-primary);
      border-color: var(--accent-primary);
    }}

    .table-scroll-wrap {{
      overflow-x: auto;
      max-height: 520px;
    }}

    table.data-table {{
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 0.78rem;
    }}

    table.data-table th {{
      background: var(--bg-card-subtle);
      color: var(--text-secondary);
      font-weight: 700;
      padding: 10px 14px;
      border-bottom: 1px solid var(--border-color);
      white-space: nowrap;
      cursor: pointer;
      user-select: none;
      transition: background 0.15s ease;
      position: sticky;
      top: 0;
      z-index: 5;
    }}

    table.data-table th:hover {{
      background: var(--bg-hover);
      color: var(--accent-primary);
    }}

    table.data-table td {{
      padding: 10px 14px;
      border-bottom: 1px solid var(--border-subtle);
      color: var(--text-primary);
      white-space: nowrap;
    }}

    table.data-table tr:hover td {{
      background: var(--bg-hover);
    }}

    .status-badge {{
      padding: 2px 7px;
      border-radius: var(--radius-full);
      font-size: 0.68rem;
      font-weight: 600;
      display: inline-block;
    }}

    .status-completed {{ background: var(--success-subtle); color: var(--success-text); }}
    .status-shipped {{ background: var(--info-subtle); color: var(--info-text); }}
    .status-pending {{ background: var(--warning-subtle); color: var(--warning-text); }}
    .status-returned-yes {{ background: var(--danger-subtle); color: var(--danger-text); }}
    .status-returned-no {{ background: var(--success-subtle); color: var(--success-text); }}

    .table-pagination-bar {{
      padding: 12px 22px;
      border-top: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
      font-size: 0.75rem;
      color: var(--text-muted);
    }}

    .pagination-actions {{
      display: flex;
      align-items: center;
      gap: 4px;
    }}

    .page-btn {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      color: var(--text-primary);
      padding: 4px 10px;
      border-radius: var(--radius-sm);
      cursor: pointer;
      font-size: 0.75rem;
      font-weight: 600;
      transition: all 0.15s ease;
    }}

    .page-btn:hover:not(:disabled) {{
      background: var(--accent-subtle);
      color: var(--accent-primary);
    }}

    .page-btn.active {{
      background: var(--accent-primary);
      color: #ffffff;
      border-color: var(--accent-primary);
    }}

    .page-btn:disabled {{
      opacity: 0.4;
      cursor: not-allowed;
    }}

    /* Empty state */
    .empty-state {{
      padding: 60px 20px;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      color: var(--text-muted);
    }}

    .empty-state svg {{
      width: 48px;
      height: 48px;
      color: var(--text-muted);
      opacity: 0.6;
    }}

    .empty-state h3 {{
      font-size: 1.1rem;
      color: var(--text-primary);
      font-weight: 700;
    }}

    .empty-state p {{
      font-size: 0.85rem;
      max-width: 400px;
    }}

    /* ==========================================================================
       RESPONSIVE & PRINT MEDIA
       ========================================================================== */
    @media (max-width: 1200px) {{
      .grid-2col {{
        grid-template-columns: 1fr;
      }}
    }}

    @media (max-width: 992px) {{
      .sidebar {{
        position: fixed;
        left: 0;
        top: 0;
        bottom: 0;
        transform: translateX(-100%);
        box-shadow: var(--shadow-lg);
      }}

      .sidebar.open {{
        transform: translateX(0);
      }}

      .btn-mobile-sidebar {{
        display: inline-flex;
      }}

      .content-area {{
        padding: 20px 16px 40px;
      }}

      .main-header {{
        padding: 14px 16px;
      }}

      .active-filters-bar {{
        padding: 10px 16px;
      }}
    }}

    @media print {{
      body {{
        background: #ffffff;
        color: #000000;
      }}
      .sidebar, .main-header .header-actions, .active-filters-bar, .table-controls-wrap, .table-pagination-bar {{
        display: none !important;
      }}
      .main-wrapper {{
        height: auto;
        overflow: visible;
      }}
      .chart-card, .kpi-card, .insights-panel {{
        box-shadow: none !important;
        border: 1px solid #cccccc !important;
        break-inside: avoid;
      }}
      .chart-container {{
        height: 250px !important;
      }}
    }}
  </style>
</head>
<body>

  <!-- ==========================================================================
       LEFT SIDEBAR (FILTERS & NAVIGATION)
       ========================================================================== -->
  <aside class="sidebar" id="sidebar">
    <!-- Brand Title -->
    <div class="sidebar-header">
      <div class="brand-logo">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 3v18h18"/>
          <path d="m19 9-5 5-4-4-3 3"/>
        </svg>
      </div>
      <div>
        <div class="brand-title">Executive BI</div>
        <div class="brand-subtitle">Sales & Profit Suite</div>
      </div>
    </div>

    <!-- Quick Section Navigation -->
    <div class="quick-nav">
      <div class="nav-label">Dashboard Sections</div>
      <ul class="nav-list">
        <li class="nav-item"><a href="#section-overview" class="active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>Executive Overview</a></li>
        <li class="nav-item"><a href="#section-trends"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>Sales & Profit Trends</a></li>
        <li class="nav-item"><a href="#section-breakdowns"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>Category & Region</a></li>
        <li class="nav-item"><a href="#section-brands"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/></svg>Brand & Products</a></li>
        <li class="nav-item"><a href="#section-scatter"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="18.5" cy="5.5" r=".5" fill="currentColor"/><circle cx="11.5" cy="11.5" r=".5" fill="currentColor"/><circle cx="7.5" cy="16.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="14.5" r=".5" fill="currentColor"/></svg>Discount vs Margin</a></li>
        <li class="nav-item"><a href="#section-insights"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4"/><path d="m4.93 4.93 2.83 2.83"/><path d="M2 12h4"/><path d="m4.93 19.07 2.83-2.83"/><path d="M12 22v-4"/><path d="m19.07 19.07-2.83-2.83"/><path d="M22 12h-4"/><path d="m19.07 4.93-2.83 2.83"/><circle cx="12" cy="12" r="3"/></svg>Strategic Insights</a></li>
        <li class="nav-item"><a href="#section-table"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3h18v18H3z"/><path d="M21 9H3"/><path d="M21 15H3"/><path d="M12 3v18"/></svg>Transaction Explorer</a></li>
      </ul>
    </div>

    <!-- Filter Console -->
    <div class="filter-section">
      <div class="filter-header-bar">
        <div class="nav-label" style="margin:0;">
          Interactive Filters <span class="filter-count-badge" id="activeFilterBadge">0 Active</span>
        </div>
        <button type="button" class="btn-reset-filters" id="btnResetFilters" title="Clear all filters">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
          Reset
        </button>
      </div>

      <!-- Quick Search -->
      <div class="filter-group">
        <label class="filter-title" for="searchGlobal">Global Search</label>
        <div class="search-wrapper">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="text" id="searchGlobal" class="form-control" placeholder="Customer, Product, City...">
        </div>
      </div>

      <!-- Year Filter -->
      <div class="filter-group">
        <div class="filter-title">
          <span>Fiscal Year</span>
          <span class="hint">*2025 partial</span>
        </div>
        <div class="pill-group" id="filterYears">
          <button type="button" class="pill-btn active" data-val="ALL">All</button>
          <button type="button" class="pill-btn" data-val="2023">2023</button>
          <button type="button" class="pill-btn" data-val="2024">2024</button>
          <button type="button" class="pill-btn" data-val="2025">2025*</button>
        </div>
      </div>

      <!-- Quarter Filter -->
      <div class="filter-group">
        <div class="filter-title">Quarter (Q1 - Q4)</div>
        <div class="pill-group" id="filterQuarters">
          <button type="button" class="pill-btn" data-val="Q1">Q1</button>
          <button type="button" class="pill-btn" data-val="Q2">Q2</button>
          <button type="button" class="pill-btn" data-val="Q3">Q3</button>
          <button type="button" class="pill-btn" data-val="Q4">Q4</button>
        </div>
      </div>

      <!-- Date Range Filter -->
      <div class="filter-group">
        <div class="filter-title">Custom Date Range</div>
        <div class="date-range-row">
          <div class="date-input-group">
            <label for="filterDateStart">From</label>
            <input type="date" id="filterDateStart" class="form-control" min="2023-05-03" max="2025-04-28">
          </div>
          <div class="date-input-group">
            <label for="filterDateEnd">To</label>
            <input type="date" id="filterDateEnd" class="form-control" min="2023-05-03" max="2025-04-28">
          </div>
        </div>
      </div>

      <!-- Region Multi-select -->
      <div class="filter-group">
        <div class="filter-title">Region (Multi-Select)</div>
        <div class="pill-group" id="filterRegions">
          <button type="button" class="pill-btn" data-val="Central">Central</button>
          <button type="button" class="pill-btn" data-val="North">North</button>
          <button type="button" class="pill-btn" data-val="South">South</button>
          <button type="button" class="pill-btn" data-val="West">West</button>
        </div>
      </div>

      <!-- Category Multi-select -->
      <div class="filter-group">
        <div class="filter-title">Product Category</div>
        <div class="pill-group" id="filterCategories">
          <button type="button" class="pill-btn" data-val="Accessories">Accessories</button>
          <button type="button" class="pill-btn" data-val="Appliances">Appliances</button>
          <button type="button" class="pill-btn" data-val="Electronics">Electronics</button>
          <button type="button" class="pill-btn" data-val="Furniture">Furniture</button>
          <button type="button" class="pill-btn" data-val="Stationery">Stationery</button>
        </div>
      </div>

      <!-- Brand Multi-select -->
      <div class="filter-group">
        <div class="filter-title">Brand</div>
        <div class="pill-group" id="filterBrands">
          <button type="button" class="pill-btn" data-val="Apple">Apple</button>
          <button type="button" class="pill-btn" data-val="Dell">Dell</button>
          <button type="button" class="pill-btn" data-val="HP">HP</button>
        </div>
      </div>

      <!-- Sales Person (Searchable Dropdown) -->
      <div class="filter-group">
        <div class="filter-title">Sales Representative (39 Reps)</div>
        <div class="custom-select-wrapper">
          <input type="text" id="salesRepSearch" class="form-control" placeholder="Select or type rep name..." autocomplete="off">
          <div class="rep-dropdown-list" id="repDropdownList">
            <!-- Populated via JS -->
          </div>
        </div>
      </div>

      <!-- Order Status -->
      <div class="filter-group">
        <div class="filter-title">Order Fulfillment Status</div>
        <div class="pill-group" id="filterOrderStatus">
          <button type="button" class="pill-btn" data-val="Completed">Completed</button>
          <button type="button" class="pill-btn" data-val="Shipped">Shipped</button>
          <button type="button" class="pill-btn" data-val="Pending">Pending</button>
        </div>
      </div>

      <!-- Return Status -->
      <div class="filter-group">
        <div class="filter-title">Return Status</div>
        <div class="segmented-control" id="filterReturnStatus">
          <button type="button" class="seg-btn active" data-val="ALL">All Orders</button>
          <button type="button" class="seg-btn" data-val="No">Retained (No)</button>
          <button type="button" class="seg-btn" data-val="Yes">Returned (Yes)</button>
        </div>
      </div>
    </div>
  </aside>

  <!-- ==========================================================================
       MAIN CONTENT CONTAINER
       ========================================================================== -->
  <main class="main-wrapper" id="mainWrapper">
    <!-- Top Executive Header -->
    <header class="main-header">
      <div class="header-left">
        <div class="header-title-row">
          <button class="btn-mobile-sidebar" id="btnToggleMobileSidebar" aria-label="Toggle Navigation">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>
          <h1 class="header-title">Executive Sales &amp; Profit Dashboard</h1>
          <span class="header-badge badge-date">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            May 2023 – Apr 2025
          </span>
          <span class="header-badge badge-partial-year">
            ⚠️ 2025 Partial Year (Jan–Apr)
          </span>
        </div>
        <div class="header-subtitle">
          <span>Sales Performance, Profitability &amp; Operations Overview</span>
          <span>•</span>
          <span id="headerRecordSummary">500 total orders analyzed</span>
        </div>
      </div>

      <div class="header-actions">
        <button type="button" class="btn-header-action" id="btnThemeToggle" title="Toggle Light/Dark Theme">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" id="themeIconSun"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
          <span id="themeToggleLabel">Dark Mode</span>
        </button>
        <button type="button" class="btn-header-action" onclick="window.print()" title="Print Dashboard / Export PDF">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/></svg>
          Export
        </button>
        <button type="button" class="btn-header-action" id="btnQuickReset" title="Reset all applied filters">
          Reset All
        </button>
      </div>
    </header>

    <!-- Active Filter Chips Bar -->
    <div class="active-filters-bar" id="activeFilterBar">
      <div class="active-chips-wrap" id="activeChipsContainer">
        <span style="color:var(--text-muted);">Active Scope: Complete Portfolio (No Slicers Applied)</span>
      </div>
      <div class="filter-data-status">
        <span>Records: <strong id="statActiveCount">500</strong> / 500 (<span id="statActivePct">100.0%</span>)</span>
      </div>
    </div>

    <!-- Main Dashboard Content -->
    <div class="content-area">

      <!-- ======================================================================
           SECTION 1: KPI CARDS (6 PRIMARY + 1 AUXILIARY)
           ====================================================================== -->
      <section id="section-overview">
        <div class="section-header">
          <div>
            <h2 class="section-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
              Executive Performance Scorecard
            </h2>
            <div class="section-desc">Key revenue, profitability, transaction volume, and fulfillment health indicators</div>
          </div>
        </div>

        <div class="kpi-grid">
          <!-- KPI 1: Total Sales -->
          <div class="kpi-card card-sales">
            <div class="kpi-top">
              <span class="kpi-label">Total Sales (Revenue)</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiSales">$1,936,313</div>
            <div class="kpi-footer">
              <span class="kpi-trend positive" id="kpiSalesTrend">▲ +41.6% YoY</span>
              <span class="kpi-subtext">Sum of Sales (Net)</span>
            </div>
          </div>

          <!-- KPI 2: Total Profit -->
          <div class="kpi-card card-profit">
            <div class="kpi-top">
              <span class="kpi-label">Total Profit</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiProfit">$593,391</div>
            <div class="kpi-footer">
              <span class="kpi-trend positive" id="kpiProfitTrend">▲ +37.4% YoY</span>
              <span class="kpi-subtext">Gross/Net Profit</span>
            </div>
          </div>

          <!-- KPI 3: Overall Profit Margin % -->
          <div class="kpi-card card-margin">
            <div class="kpi-top">
              <span class="kpi-label">Overall Profit Margin</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiMargin">30.6%</div>
            <div class="kpi-footer">
              <span class="kpi-trend positive" id="kpiMarginTarget">Target: >25.0%</span>
              <span class="kpi-subtext">Profit ÷ Sales × 100</span>
            </div>
          </div>

          <!-- KPI 4: Total Orders -->
          <div class="kpi-card card-orders">
            <div class="kpi-top">
              <span class="kpi-label">Total Orders</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiOrders">500</div>
            <div class="kpi-footer">
              <span class="kpi-trend neutral" id="kpiOrdersTrend">100% Unique IDs</span>
              <span class="kpi-subtext">Distinct Order Count</span>
            </div>
          </div>

          <!-- KPI 5: Average Order Value (AOV) -->
          <div class="kpi-card card-aov">
            <div class="kpi-top">
              <span class="kpi-label">Average Order Value</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiAOV">$3,873</div>
            <div class="kpi-footer">
              <span class="kpi-trend neutral" id="kpiAOVTrend">~5.5 Units/Order</span>
              <span class="kpi-subtext">Sales ÷ Total Orders</span>
            </div>
          </div>

          <!-- KPI 6: Return Rate % -->
          <div class="kpi-card card-return">
            <div class="kpi-top">
              <span class="kpi-label">Return Rate %</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="9 14 4 9 9 4"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiReturnRate">49.6%</div>
            <div class="kpi-footer">
              <span class="kpi-trend warning" id="kpiReturnRisk">⚠️ High Severity</span>
              <span class="kpi-subtext" id="kpiReturnCount">248 Returned Orders</span>
            </div>
          </div>

          <!-- KPI 7 (Auxiliary): Customer Base & Discounting -->
          <div class="kpi-card card-customers">
            <div class="kpi-top">
              <span class="kpi-label">Audience &amp; Pricing</span>
              <div class="kpi-icon-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
              </div>
            </div>
            <div class="kpi-value" id="kpiCustomers" style="font-size:1.6rem;">318 <span style="font-size:1rem;font-weight:600;color:var(--text-muted);">Cust</span></div>
            <div class="kpi-footer">
              <span class="kpi-trend neutral" id="kpiAvgDiscount">Avg 7.6% Disc</span>
              <span class="kpi-subtext">39 Sales Reps</span>
            </div>
          </div>
        </div>
      </section>

      <!-- ======================================================================
           SECTION 2: CHART 1 (SALES & PROFIT TREND OVER TIME)
           ====================================================================== -->
      <section id="section-trends">
        <div class="chart-card">
          <div class="chart-card-header">
            <div class="chart-title-group">
              <h3 class="chart-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                Revenue &amp; Profitability Trajectory Over Time
              </h3>
              <div class="chart-subtitle">Chronological dual-axis comparison: Net Sales (bars) vs. Profit (line) across historical periods</div>
            </div>
            <div class="chart-controls">
              <button type="button" class="chart-toggle-btn active" data-trend-grain="monthly">Monthly (24 Mo)</button>
              <button type="button" class="chart-toggle-btn" data-trend-grain="quarterly">Quarterly</button>
              <button type="button" class="chart-toggle-btn" data-trend-grain="yearly">Yearly</button>
            </div>
          </div>

          <div class="chart-container tall">
            <canvas id="chartTrend"></canvas>
          </div>

          <div class="chart-note-callout">
            <div>
              <strong>Executive Period Notice:</strong> 2023 begins in May (8 months); 2024 is a full fiscal year (12 months); 2025 runs through April only (4 months).
            </div>
            <div class="stats-inline-chips">
              <div class="stat-chip">Peak Month: <span class="val" id="statPeakMonth">Jul-24 ($128.5K)</span></div>
              <div class="stat-chip">Avg Monthly Run Rate: <span class="val" id="statAvgMonth">$80.7K</span></div>
            </div>
          </div>
        </div>
      </section>

      <!-- ======================================================================
           SECTION 3: CATEGORY & REGIONAL ANALYSIS (CHARTS 2 & 3)
           ====================================================================== -->
      <section id="section-breakdowns">
        <div class="grid-2col">
          <!-- Chart 2: Category Breakdown -->
          <div class="chart-card">
            <div class="chart-card-header">
              <div class="chart-title-group">
                <h3 class="chart-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                  Category Sales &amp; Margin %
                </h3>
                <div class="chart-subtitle">Sales volume ($) vs. Profit Margin yield (%) across 5 product categories</div>
              </div>
            </div>
            <div class="chart-container">
              <canvas id="chartCategory"></canvas>
            </div>
            <div class="chart-note-callout" style="border-left-color: var(--accent-teal);">
              <span>💡 <strong>Insight:</strong> Electronics leads in volume ($660K), but Furniture leads in margin efficiency (33.5%).</span>
            </div>
          </div>

          <!-- Chart 3: Regional Performance -->
          <div class="chart-card">
            <div class="chart-card-header">
              <div class="chart-title-group">
                <h3 class="chart-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
                  Regional Performance &amp; Margins
                </h3>
                <div class="chart-subtitle">Sales and Profit comparison across Central, North, South, and West territories</div>
              </div>
            </div>
            <div class="chart-container">
              <canvas id="chartRegion"></canvas>
            </div>
            <div class="chart-note-callout" style="border-left-color: #6366f1;">
              <span>💡 <strong>Insight:</strong> West is the volume driver ($628K Sales); North achieves the highest profitability (32.3% margin).</span>
            </div>
          </div>
        </div>
      </section>

      <!-- ======================================================================
           SECTION 4: BRAND & PRODUCT PERFORMANCE (CHARTS 4 & 5)
           ====================================================================== -->
      <section id="section-brands">
        <div class="grid-2col">
          <!-- Chart 4: Brand Comparison -->
          <div class="chart-card">
            <div class="chart-card-header">
              <div class="chart-title-group">
                <h3 class="chart-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/></svg>
                  Brand Comparison: Sales &amp; Margin
                </h3>
                <div class="chart-subtitle">Revenue capture and profit margin comparison across Apple, Dell, and HP</div>
              </div>
            </div>
            <div class="chart-container">
              <canvas id="chartBrand"></canvas>
            </div>
            <div class="chart-note-callout" style="border-left-color: #8b5cf6;">
              <span>💡 <strong>Insight:</strong> Dell delivers the best profit margin (32.9%), outperforming HP (30.0%) and Apple (29.1%).</span>
            </div>
          </div>

          <!-- Chart 5: Top 10 Products / Reps Ranking -->
          <div class="chart-card">
            <div class="chart-card-header">
              <div class="chart-title-group">
                <h3 class="chart-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                  <span id="rankingTitleText">Top 10 Products by Revenue</span>
                </h3>
                <div class="chart-subtitle">Ranked by Net Sales with accompanying Profit contributions</div>
              </div>
              <div class="chart-controls">
                <button type="button" class="chart-toggle-btn active" id="btnRankProducts">Products</button>
                <button type="button" class="chart-toggle-btn" id="btnRankReps">Sales Reps</button>
              </div>
            </div>
            <div class="chart-container">
              <canvas id="chartTop10"></canvas>
            </div>
            <div class="chart-note-callout" style="border-left-color: var(--accent-primary);">
              <span id="rankingCalloutText">💡 <strong>Leader:</strong> Dell Laptop generates highest SKU revenue ($152.9K) and profit ($47.9K).</span>
            </div>
          </div>
        </div>
      </section>

      <!-- ======================================================================
           SECTION 5: ADVANCED ANALYTICS (DISCOUNT VS MARGIN & OPERATIONAL HEALTH)
           ====================================================================== -->
      <section id="section-scatter">
        <div class="grid-2col">
          <!-- Chart 6: Discount vs Profit Margin Scatter -->
          <div class="chart-card">
            <div class="chart-card-header">
              <div class="chart-title-group">
                <h3 class="chart-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="18.5" cy="5.5" r=".5" fill="currentColor"/><circle cx="11.5" cy="11.5" r=".5" fill="currentColor"/><circle cx="7.5" cy="16.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="14.5" r=".5" fill="currentColor"/></svg>
                  Discount % vs. Profit Margin % Correlation
                </h3>
                <div class="chart-subtitle">Transaction-level scatter plot evaluating the profitability impact of discounting</div>
              </div>
            </div>

            <div class="scatter-stat-banner">
              <span>Statistical Evaluation:</span>
              <span class="correlation-badge" id="corrBadge">r = -0.4635 (Moderate Negative)</span>
            </div>

            <div class="chart-container" style="height:270px;">
              <canvas id="chartScatter"></canvas>
            </div>

            <div class="chart-note-callout" style="border-left-color: var(--danger);">
              <span>⚠️ <strong>Policy Warning:</strong> Heavier discounting significantly erodes margins. Deep discounts (>15%) require governance.</span>
            </div>
          </div>

          <!-- Chart 7: Operational Health Breakdown -->
          <div class="chart-card">
            <div class="chart-card-header">
              <div class="chart-title-group">
                <h3 class="chart-title">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                  Operational Health &amp; Fulfillment
                </h3>
                <div class="chart-subtitle">Distribution of order status, payment modes, and return rates</div>
              </div>
              <div class="chart-controls">
                <button type="button" class="chart-toggle-btn active" data-ops-slice="orderStatus">Status</button>
                <button type="button" class="chart-toggle-btn" data-ops-slice="paymentMode">Payment</button>
                <button type="button" class="chart-toggle-btn" data-ops-slice="returnStatus">Returns</button>
              </div>
            </div>

            <div class="chart-container">
              <canvas id="chartOperations"></canvas>
            </div>

            <div class="chart-note-callout" style="border-left-color: var(--warning);">
              <span id="opsCalloutText">⚠️ <strong>Operations Risk:</strong> Return rate stands at 49.6% (248 returns) — nearly 1 in 2 orders returned.</span>
            </div>
          </div>
        </div>
      </section>

      <!-- ======================================================================
           SECTION 6: DYNAMIC KEY BUSINESS INSIGHTS PANEL
           ====================================================================== -->
      <section id="section-insights">
        <div class="insights-panel">
          <div class="insights-header">
            <div>
              <h2 class="section-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg>
                Executive Strategic Insights &amp; Recommendations
              </h2>
              <div class="section-desc">Dynamically generated diagnostic findings and leadership action items computed from the active dataset</div>
            </div>
            <span class="filter-count-badge" id="insightsRecalcBadge">Recalculated Live</span>
          </div>

          <div class="insights-grid" id="insightsGrid">
            <!-- Dynamically populated via JS -->
          </div>
        </div>
      </section>

      <!-- ======================================================================
           SECTION 7: TRANSACTION DETAIL EXPLORER (COLLAPSIBLE AUDIT TABLE)
           ====================================================================== -->
      <section id="section-table">
        <div class="table-section-card">
          <div class="table-header-bar" id="tableHeaderBar">
            <div class="table-collapse-trigger">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="table-collapse-icon" id="tableCollapseIcon"><polyline points="6 9 12 15 18 9"/></svg>
              <div>
                <h3 class="chart-title" style="margin:0;">Transaction Records &amp; Audit Explorer</h3>
                <div class="chart-subtitle">Order-level granularity for operational compliance and drill-down analysis</div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
              <span class="header-badge badge-date" id="tableRecordBadge">500 Records</span>
              <button type="button" class="table-export-btn" id="btnExportCSV">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Export CSV
              </button>
            </div>
          </div>

          <div id="tableCollapseBody">
            <div class="table-controls-wrap">
              <div class="table-search-box search-wrapper">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="text" id="tableFilterInput" class="form-control" placeholder="Search table records...">
              </div>
              <div style="display:flex;align-items:center;gap:8px;">
                <label for="tablePageSize" style="font-size:0.75rem;color:var(--text-muted);font-weight:600;">Rows per page:</label>
                <select id="tablePageSize" class="form-control" style="width:75px;padding:4px 8px;">
                  <option value="10">10</option>
                  <option value="25" selected>25</option>
                  <option value="50">50</option>
                  <option value="100">100</option>
                </select>
              </div>
            </div>

            <div class="table-scroll-wrap">
              <table class="data-table" id="transactionTable">
                <thead>
                  <tr>
                    <th data-col="orderId">Order ID ⬍</th>
                    <th data-col="orderDate">Date ⬍</th>
                    <th data-col="customerName">Customer ⬍</th>
                    <th data-col="productName">Product Name ⬍</th>
                    <th data-col="category">Category ⬍</th>
                    <th data-col="brand">Brand ⬍</th>
                    <th data-col="region">Region ⬍</th>
                    <th data-col="salesPerson">Sales Rep ⬍</th>
                    <th data-col="sales" style="text-align:right;">Sales ($) ⬍</th>
                    <th data-col="profit" style="text-align:right;">Profit ($) ⬍</th>
                    <th data-col="profitMargin" style="text-align:right;">Margin % ⬍</th>
                    <th data-col="orderStatus">Status ⬍</th>
                    <th data-col="returnStatus">Returned ⬍</th>
                  </tr>
                </thead>
                <tbody id="tableBody">
                  <!-- Populated via JS -->
                </tbody>
              </table>
              <div id="tableEmptyState" class="empty-state" style="display:none;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <h3>No Matching Records</h3>
                <p>No transactions match the selected filters or search terms. Try adjusting your search or clearing active filters.</p>
                <button type="button" class="btn-header-action" onclick="resetAllFilters()">Reset Filters</button>
              </div>
            </div>

            <div class="table-pagination-bar">
              <div id="tableShowingText">Showing 1 to 25 of 500 entries</div>
              <div class="pagination-actions" id="paginationControls">
                <!-- Pagination buttons via JS -->
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  </main>

  <!-- ==========================================================================
       EMBEDDED DATASET & LOGIC ENGINE
       ========================================================================== -->
  <script>
    /**
     * EXECUTIVE SALES & PROFIT DASHBOARD - CLIENT-SIDE ENGINE
     * Complete 500-Row Dataset Embedded from Ultimate_Sales_Profit_Dataset.xlsx (Data Sheet)
     * All calculations, filtering, dynamic insights, and Chart.js instances run client-side.
     */
    
    // 1. EMBEDDED COMPLETE DATASET (500 Transactions)
    const RAW_DATA = {dataset_json};

    // 2. STATE MANAGEMENT
    const state = {{
      filters: {{
        search: '',
        year: 'ALL',
        quarters: [],
        dateStart: '',
        dateEnd: '',
        regions: [],
        categories: [],
        brands: [],
        salesPerson: '',
        orderStatuses: [],
        returnStatus: 'ALL'
      }},
      trendGrain: 'monthly', // 'monthly', 'quarterly', 'yearly'
      rankingType: 'products', // 'products', 'reps'
      opsSlice: 'orderStatus', // 'orderStatus', 'paymentMode', 'returnStatus'
      table: {{
        page: 1,
        pageSize: 25,
        sortCol: 'orderDate',
        sortAsc: false,
        searchTerm: ''
      }},
      charts: {{
        trend: null,
        category: null,
        region: null,
        brand: null,
        top10: null,
        scatter: null,
        operations: null
      }},
      theme: localStorage.getItem('bi_dashboard_theme') || 'light'
    }};

    // 3. UTILITY FORMATTERS
    const fmtCurrency = (val) => {{
      if (val === null || val === undefined || isNaN(val)) return '$0';
      return '$' + Math.round(val).toLocaleString('en-US');
    }};

    const fmtCurrencyDecimal = (val) => {{
      if (val === null || val === undefined || isNaN(val)) return '$0.00';
      return '$' + Number(val).toLocaleString('en-US', {{ minimumFractionDigits: 2, maximumFractionDigits: 2 }});
    }};

    const fmtPct = (val) => {{
      if (val === null || val === undefined || isNaN(val)) return '0.0%';
      return Number(val).toFixed(1) + '%';
    }};

    const fmtNumber = (val) => {{
      if (val === null || val === undefined || isNaN(val)) return '0';
      return Number(val).toLocaleString('en-US');
    }};

    // 4. FILTERING LOGIC
    function getFilteredData() {{
      const f = state.filters;
      const searchLower = f.search.trim().toLowerCase();

      return RAW_DATA.filter(row => {{
        // Global search
        if (searchLower) {{
          const matchGlobal = 
            row.customerName.toLowerCase().includes(searchLower) ||
            row.productName.toLowerCase().includes(searchLower) ||
            row.salesPerson.toLowerCase().includes(searchLower) ||
            row.city.toLowerCase().includes(searchLower) ||
            row.orderId.toLowerCase().includes(searchLower) ||
            row.brand.toLowerCase().includes(searchLower) ||
            row.category.toLowerCase().includes(searchLower);
          if (!matchGlobal) return false;
        }}

        // Year filter
        if (f.year !== 'ALL' && row.year !== parseInt(f.year, 10)) {{
          return false;
        }}

        // Quarter filter
        if (f.quarters.length > 0 && !f.quarters.includes(row.quarter)) {{
          return false;
        }}

        // Date range
        if (f.dateStart && row.orderDate < f.dateStart) return false;
        if (f.dateEnd && row.orderDate > f.dateEnd) return false;

        // Region multi-select
        if (f.regions.length > 0 && !f.regions.includes(row.region)) {{
          return false;
        }}

        // Category multi-select
        if (f.categories.length > 0 && !f.categories.includes(row.category)) {{
          return false;
        }}

        // Brand multi-select
        if (f.brands.length > 0 && !f.brands.includes(row.brand)) {{
          return false;
        }}

        // Sales Person
        if (f.salesPerson && row.salesPerson !== f.salesPerson) {{
          return false;
        }}

        // Order fulfillment status
        if (f.orderStatuses.length > 0 && !f.orderStatuses.includes(row.orderStatus)) {{
          return false;
        }}

        // Return status
        if (f.returnStatus !== 'ALL' && row.returnStatus !== f.returnStatus) {{
          return false;
        }}

        return true;
      }});
    }}

    // 5. CALCULATION ENGINE
    function calculateKPIs(data) {{
      if (!data || data.length === 0) {{
        return {{
          totalSales: 0,
          totalProfit: 0,
          profitMargin: 0,
          totalOrders: 0,
          aov: 0,
          returnRate: 0,
          returnCount: 0,
          uniqueCustomers: 0,
          avgDiscount: 0,
          yoySalesGrowth: null,
          yoyProfitGrowth: null,
          isPartialNotice: false
        }};
      }}

      // Core Totals
      const totalSales = data.reduce((acc, r) => acc + r.sales, 0);
      const totalProfit = data.reduce((acc, r) => acc + r.profit, 0);
      // Rule: Weighted profit margin = total Profit / total Sales * 100
      const profitMargin = totalSales > 0 ? (totalProfit / totalSales) * 100 : 0;
      
      // Distinct order IDs
      const orderSet = new Set(data.map(r => r.orderId));
      const totalOrders = orderSet.size;
      const aov = totalOrders > 0 ? totalSales / totalOrders : 0;

      // Return Rate %
      const returnOrders = data.filter(r => r.returnStatus.toLowerCase() === 'yes').length;
      const returnRate = totalOrders > 0 ? (returnOrders / totalOrders) * 100 : 0;

      // Unique customers & Avg Discount
      const uniqueCustomers = new Set(data.map(r => r.customerId)).size;
      const avgDiscount = data.reduce((acc, r) => acc + r.discount, 0) / data.length;

      // Period Growth Comparison Logic
      // If full dataset (or no year filter): Compare 2024 vs 2023 full year, and 2025 (Jan-Apr) vs 2024 (Jan-Apr) equivalent
      let yoySalesGrowth = null;
      let yoyProfitGrowth = null;

      const sales2023 = data.filter(r => r.year === 2023).reduce((acc, r) => acc + r.sales, 0);
      const sales2024 = data.filter(r => r.year === 2024).reduce((acc, r) => acc + r.sales, 0);
      const sales2025 = data.filter(r => r.year === 2025).reduce((acc, r) => acc + r.sales, 0);

      const profit2023 = data.filter(r => r.year === 2023).reduce((acc, r) => acc + r.profit, 0);
      const profit2024 = data.filter(r => r.year === 2024).reduce((acc, r) => acc + r.profit, 0);
      const profit2025 = data.filter(r => r.year === 2025).reduce((acc, r) => acc + r.profit, 0);

      if (state.filters.year === '2025') {{
        // Equivalent period: Jan-Apr 2024 vs Jan-Apr 2025
        const s24_4m = RAW_DATA.filter(r => r.year === 2024 && r.monthNo <= 4).reduce((acc, r) => acc + r.sales, 0);
        const p24_4m = RAW_DATA.filter(r => r.year === 2024 && r.monthNo <= 4).reduce((acc, r) => acc + r.profit, 0);
        if (s24_4m > 0) yoySalesGrowth = ((totalSales - s24_4m) / s24_4m) * 100;
        if (p24_4m > 0) yoyProfitGrowth = ((totalProfit - p24_4m) / p24_4m) * 100;
      }} else if (state.filters.year === '2024' && sales2023 > 0) {{
        yoySalesGrowth = ((sales2024 - sales2023) / sales2023) * 100;
        yoyProfitGrowth = ((profit2024 - profit2023) / profit2023) * 100;
      }} else if (sales2023 > 0 && sales2024 > 0) {{
        yoySalesGrowth = ((sales2024 - sales2023) / sales2023) * 100;
        yoyProfitGrowth = ((profit2024 - profit2023) / profit2023) * 100;
      }}

      return {{
        totalSales,
        totalProfit,
        profitMargin,
        totalOrders,
        aov,
        returnRate,
        returnCount: returnOrders,
        uniqueCustomers,
        avgDiscount,
        yoySalesGrowth,
        yoyProfitGrowth
      }};
    }}

    // Pearson Correlation Coefficient (r) between Discount % and Profit Margin %
    function calculatePearsonCorrelation(data) {{
      if (!data || data.length < 2) return 0;
      const n = data.length;
      let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;

      for (let i = 0; i < n; i++) {{
        const x = data[i].discount;
        const y = data[i].profitMargin;
        sumX += x;
        sumY += y;
        sumXY += x * y;
        sumX2 += x * x;
        sumY2 += y * y;
      }}

      const numerator = (n * sumXY) - (sumX * sumY);
      const denominator = Math.sqrt(((n * sumX2) - (sumX * sumX)) * ((n * sumY2) - (sumY * sumY)));
      if (denominator === 0) return 0;
      return numerator / denominator;
    }}

    // Linear regression slope and intercept for trendline
    function calculateLinearRegression(data) {{
      if (!data || data.length < 2) return {{ slope: 0, intercept: 0 }};
      const n = data.length;
      let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
      for (let i = 0; i < n; i++) {{
        const x = data[i].discount;
        const y = data[i].profitMargin;
        sumX += x;
        sumY += y;
        sumXY += x * y;
        sumX2 += x * x;
      }}
      const slope = ((n * sumXY) - (sumX * sumY)) / ((n * sumX2) - (sumX * sumX));
      const intercept = (sumY - (slope * sumX)) / n;
      return {{ slope, intercept }};
    }}

    // 6. UI UPDATERS
    function updateKPICards(kpi) {{
      document.getElementById('kpiSales').textContent = fmtCurrency(kpi.totalSales);
      document.getElementById('kpiProfit').textContent = fmtCurrency(kpi.totalProfit);
      document.getElementById('kpiMargin').textContent = fmtPct(kpi.profitMargin);
      document.getElementById('kpiOrders').textContent = fmtNumber(kpi.totalOrders);
      document.getElementById('kpiAOV').textContent = fmtCurrency(kpi.aov);
      document.getElementById('kpiReturnRate').textContent = fmtPct(kpi.returnRate);
      document.getElementById('kpiReturnCount').textContent = `${{kpi.returnCount}} Returned Orders`;
      document.getElementById('kpiCustomers').innerHTML = `${{kpi.uniqueCustomers}} <span style="font-size:1rem;font-weight:600;color:var(--text-muted);">Cust</span>`;
      document.getElementById('kpiAvgDiscount').textContent = `Avg ${{fmtPct(kpi.avgDiscount)}} Disc`;

      // Trend labels
      const salesTrendEl = document.getElementById('kpiSalesTrend');
      const profitTrendEl = document.getElementById('kpiProfitTrend');

      if (kpi.yoySalesGrowth !== null) {{
        const sign = kpi.yoySalesGrowth >= 0 ? '▲ +' : '▼ ';
        const prefix = state.filters.year === '2025' ? 'Equivalent 4M: ' : 'YoY Growth: ';
        salesTrendEl.textContent = `${{sign}}${{Math.abs(kpi.yoySalesGrowth).toFixed(1)}}% ${{prefix}}`;
        salesTrendEl.className = `kpi-trend ${{kpi.yoySalesGrowth >= 0 ? 'positive' : 'negative'}}`;
      }} else {{
        salesTrendEl.textContent = 'Filtered Horizon';
        salesTrendEl.className = 'kpi-trend neutral';
      }}

      if (kpi.yoyProfitGrowth !== null) {{
        const sign = kpi.yoyProfitGrowth >= 0 ? '▲ +' : '▼ ';
        profitTrendEl.textContent = `${{sign}}${{Math.abs(kpi.yoyProfitGrowth).toFixed(1)}}%`;
        profitTrendEl.className = `kpi-trend ${{kpi.yoyProfitGrowth >= 0 ? 'positive' : 'negative'}}`;
      }} else {{
        profitTrendEl.textContent = `${{fmtPct(kpi.profitMargin)}} Yield`;
        profitTrendEl.className = 'kpi-trend positive';
      }}

      // Return Rate risk tag
      const returnRiskEl = document.getElementById('kpiReturnRisk');
      if (kpi.returnRate > 40) {{
        returnRiskEl.textContent = '⚠️ High Risk';
        returnRiskEl.className = 'kpi-trend negative';
      }} else if (kpi.returnRate > 20) {{
        returnRiskEl.textContent = '⚡ Moderate Risk';
        returnRiskEl.className = 'kpi-trend warning';
      }} else {{
        returnRiskEl.textContent = '✓ Low Returns';
        returnRiskEl.className = 'kpi-trend positive';
      }}
    }}

    function updateActiveChipsBar(filteredCount) {{
      const totalCount = RAW_DATA.length;
      const pct = ((filteredCount / totalCount) * 100).toFixed(1);
      document.getElementById('statActiveCount').textContent = fmtNumber(filteredCount);
      document.getElementById('statActivePct').textContent = `${{pct}}%`;
      document.getElementById('headerRecordSummary').textContent = `${{fmtNumber(filteredCount)}} of ${{totalCount}} transactions active (${{pct}}%)`;
      document.getElementById('tableRecordBadge').textContent = `${{fmtNumber(filteredCount)}} Records`;

      const container = document.getElementById('activeChipsContainer');
      const chips = [];
      const f = state.filters;

      if (f.search) {{
        chips.push({{ key: 'search', label: `Search: "${{f.search}}"` }});
      }}
      if (f.year !== 'ALL') {{
        chips.push({{ key: 'year', label: `Year: ${{f.year}}` }});
      }}
      if (f.quarters.length > 0) {{
        chips.push({{ key: 'quarters', label: `Quarters: ${{f.quarters.join(', ')}}` }});
      }}
      if (f.dateStart || f.dateEnd) {{
        chips.push({{ key: 'date', label: `Dates: ${{f.dateStart || 'Start'}} to ${{f.dateEnd || 'End'}}` }});
      }}
      if (f.regions.length > 0) {{
        chips.push({{ key: 'regions', label: `Region: ${{f.regions.join(', ')}}` }});
      }}
      if (f.categories.length > 0) {{
        chips.push({{ key: 'categories', label: `Category: ${{f.categories.join(', ')}}` }});
      }}
      if (f.brands.length > 0) {{
        chips.push({{ key: 'brands', label: `Brand: ${{f.brands.join(', ')}}` }});
      }}
      if (f.salesPerson) {{
        chips.push({{ key: 'salesPerson', label: `Rep: ${{f.salesPerson}}` }});
      }}
      if (f.orderStatuses.length > 0) {{
        chips.push({{ key: 'orderStatuses', label: `Status: ${{f.orderStatuses.join(', ')}}` }});
      }}
      if (f.returnStatus !== 'ALL') {{
        chips.push({{ key: 'returnStatus', label: `Returns: ${{f.returnStatus === 'Yes' ? 'Returned Only' : 'Retained Only'}}` }});
      }}

      // Update Active Filter Badge in Sidebar
      const activeCount = chips.length;
      document.getElementById('activeFilterBadge').textContent = `${{activeCount}} Active`;

      if (chips.length === 0) {{
        container.innerHTML = '<span style="color:var(--text-muted);font-weight:500;">Active Scope: Complete Portfolio (All Dimensions)</span>';
      }} else {{
        container.innerHTML = chips.map(c => `
          <span class="active-chip">
            ${{c.label}}
            <button type="button" onclick="removeFilterChip('${{c.key}}')" title="Remove this filter">✕</button>
          </span>
        `).join('') + `
          <button type="button" onclick="resetAllFilters()" style="background:none;border:none;color:var(--accent-primary);font-size:0.75rem;font-weight:600;cursor:pointer;margin-left:4px;">
            Clear All
          </button>
        `;
      }}
    }}

    function removeFilterChip(key) {{
      if (key === 'search') {{
        state.filters.search = '';
        document.getElementById('searchGlobal').value = '';
      }} else if (key === 'year') {{
        state.filters.year = 'ALL';
        updatePillUI('filterYears', 'ALL');
      }} else if (key === 'quarters') {{
        state.filters.quarters = [];
        clearPillUI('filterQuarters');
      }} else if (key === 'date') {{
        state.filters.dateStart = '';
        state.filters.dateEnd = '';
        document.getElementById('filterDateStart').value = '';
        document.getElementById('filterDateEnd').value = '';
      }} else if (key === 'regions') {{
        state.filters.regions = [];
        clearPillUI('filterRegions');
      }} else if (key === 'categories') {{
        state.filters.categories = [];
        clearPillUI('filterCategories');
      }} else if (key === 'brands') {{
        state.filters.brands = [];
        clearPillUI('filterBrands');
      }} else if (key === 'salesPerson') {{
        state.filters.salesPerson = '';
        document.getElementById('salesRepSearch').value = '';
      }} else if (key === 'orderStatuses') {{
        state.filters.orderStatuses = [];
        clearPillUI('filterOrderStatus');
      }} else if (key === 'returnStatus') {{
        state.filters.returnStatus = 'ALL';
        updateSegUI('filterReturnStatus', 'ALL');
      }}
      refreshDashboard();
    }}

    // 7. CHART.JS CONFIGURATION & RENDERERS
    const chartTheme = {{
      getFont: () => ({{ family: "'Inter', sans-serif", size: 11 }}),
      getTextColor: () => state.theme === 'dark' ? '#94a3b8' : '#64748b',
      getGridColor: () => state.theme === 'dark' ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.06)',
      getTooltipTheme: () => ({{
        backgroundColor: state.theme === 'dark' ? '#0f172a' : '#1e293b',
        titleColor: '#ffffff',
        bodyColor: '#f8fafc',
        borderColor: state.theme === 'dark' ? '#334155' : '#475569',
        borderWidth: 1,
        padding: 10,
        boxPadding: 4,
        cornerRadius: 6
      }})
    }};

    // CHART 1: MONTHLY SALES & PROFIT TREND (Chronological Dual-Axis)
    function renderTrendChart(data) {{
      const ctx = document.getElementById('chartTrend').getContext('2d');
      if (state.charts.trend) state.charts.trend.destroy();

      let labels = [];
      let salesData = [];
      let profitData = [];
      let marginData = [];

      if (state.trendGrain === 'monthly') {{
        // Group by Year * 100 + MonthNo to guarantee chronological sorting
        const monthMap = new Map();
        data.forEach(r => {{
          const key = r.year * 100 + r.monthNo;
          if (!monthMap.has(key)) {{
            monthMap.set(key, {{ label: r.monthYear, year: r.year, monthNo: r.monthNo, sales: 0, profit: 0 }});
          }}
          const entry = monthMap.get(key);
          entry.sales += r.sales;
          entry.profit += r.profit;
        }});

        // Sort chronologically
        const sortedKeys = Array.from(monthMap.keys()).sort((a, b) => a - b);
        labels = sortedKeys.map(k => monthMap.get(k).label);
        salesData = sortedKeys.map(k => Math.round(monthMap.get(k).sales));
        profitData = sortedKeys.map(k => Math.round(monthMap.get(k).profit));
        marginData = sortedKeys.map(k => {{
          const s = monthMap.get(k).sales;
          const p = monthMap.get(k).profit;
          return s > 0 ? Number(((p / s) * 100).toFixed(1)) : 0;
        }});

        // Stat chips update
        if (sortedKeys.length > 0) {{
          let peakVal = 0, peakLbl = '';
          let sumSales = 0;
          sortedKeys.forEach(k => {{
            const entry = monthMap.get(k);
            sumSales += entry.sales;
            if (entry.sales > peakVal) {{
              peakVal = entry.sales;
              peakLbl = entry.label;
            }}
          }});
          document.getElementById('statPeakMonth').textContent = `${{peakLbl}} (${{fmtCurrency(peakVal)}})`;
          document.getElementById('statAvgMonth').textContent = fmtCurrency(sumSales / sortedKeys.length);
        }}
      }} else if (state.trendGrain === 'quarterly') {{
        const qMap = new Map();
        data.forEach(r => {{
          const key = `${{r.year}}-${{r.quarter}}`;
          if (!qMap.has(key)) {{
            qMap.set(key, {{ label: `${{r.year}} ${{r.quarter}}`, sales: 0, profit: 0 }});
          }}
          const entry = qMap.get(key);
          entry.sales += r.sales;
          entry.profit += r.profit;
        }});
        const sortedKeys = Array.from(qMap.keys()).sort();
        labels = sortedKeys.map(k => qMap.get(k).label);
        salesData = sortedKeys.map(k => Math.round(qMap.get(k).sales));
        profitData = sortedKeys.map(k => Math.round(qMap.get(k).profit));
        marginData = sortedKeys.map(k => {{
          const s = qMap.get(k).sales;
          const p = qMap.get(k).profit;
          return s > 0 ? Number(((p / s) * 100).toFixed(1)) : 0;
        }});
      }} else {{
        // Yearly
        const yMap = new Map();
        data.forEach(r => {{
          const key = r.year;
          if (!yMap.has(key)) {{
            yMap.set(key, {{ label: r.year === 2025 ? '2025 (Partial)' : `${{r.year}}`, sales: 0, profit: 0 }});
          }}
          const entry = yMap.get(key);
          entry.sales += r.sales;
          entry.profit += r.profit;
        }});
        const sortedKeys = Array.from(yMap.keys()).sort();
        labels = sortedKeys.map(k => yMap.get(k).label);
        salesData = sortedKeys.map(k => Math.round(yMap.get(k).sales));
        profitData = sortedKeys.map(k => Math.round(yMap.get(k).profit));
        marginData = sortedKeys.map(k => {{
          const s = yMap.get(k).sales;
          const p = yMap.get(k).profit;
          return s > 0 ? Number(((p / s) * 100).toFixed(1)) : 0;
        }});
      }}

      // Bar gradient creation
      const salesColor = state.theme === 'dark' ? 'rgba(56, 189, 248, 0.7)' : 'rgba(2, 132, 199, 0.75)';
      const salesHoverColor = state.theme === 'dark' ? '#38bdf8' : '#0284c7';
      const profitLineColor = '#10b981';

      state.charts.trend = new Chart(ctx, {{
        type: 'bar',
        data: {{
          labels: labels,
          datasets: [
            {{
              type: 'line',
              label: 'Profit ($)',
              data: profitData,
              borderColor: profitLineColor,
              backgroundColor: 'rgba(16, 185, 129, 0.12)',
              borderWidth: 2.5,
              tension: 0.35,
              pointRadius: 3.5,
              pointHoverRadius: 6,
              pointBackgroundColor: profitLineColor,
              pointBorderColor: '#ffffff',
              pointBorderWidth: 1.5,
              yAxisID: 'y1',
              order: 1
            }},
            {{
              type: 'bar',
              label: 'Net Sales ($)',
              data: salesData,
              backgroundColor: salesColor,
              hoverBackgroundColor: salesHoverColor,
              borderRadius: 4,
              maxBarThickness: 32,
              yAxisID: 'y',
              order: 2
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          interaction: {{ mode: 'index', intersect: false }},
          plugins: {{
            legend: {{
              position: 'top',
              align: 'end',
              labels: {{
                font: chartTheme.getFont(),
                color: chartTheme.getTextColor(),
                usePointStyle: true,
                pointStyle: 'circle',
                boxWidth: 8,
                padding: 16
              }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                label: function(context) {{
                  const val = context.parsed.y;
                  const idx = context.dataIndex;
                  if (context.dataset.type === 'line') {{
                    const m = marginData[idx];
                    return `Profit: ${{fmtCurrency(val)}} (${{m}}% margin)`;
                  }}
                  return `Sales: ${{fmtCurrency(val)}}`;
                }}
              }}
            }}
          }},
          scales: {{
            x: {{
              grid: {{ display: false }},
              ticks: {{
                font: chartTheme.getFont(),
                color: chartTheme.getTextColor(),
                maxRotation: 45
              }}
            }},
            y: {{
              position: 'left',
              title: {{
                display: true,
                text: 'Sales Revenue ($)',
                color: chartTheme.getTextColor(),
                font: chartTheme.getFont()
              }},
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{
                font: chartTheme.getFont(),
                color: chartTheme.getTextColor(),
                callback: (val) => '$' + (val >= 1000 ? (val / 1000) + 'k' : val)
              }}
            }},
            y1: {{
              position: 'right',
              title: {{
                display: true,
                text: 'Net Profit ($)',
                color: '#10b981',
                font: chartTheme.getFont()
              }},
              grid: {{ drawOnChartArea: false }},
              ticks: {{
                font: chartTheme.getFont(),
                color: '#10b981',
                callback: (val) => '$' + (val >= 1000 ? (val / 1000) + 'k' : val)
              }}
            }}
          }}
        }}
      }});
    }}

    // CHART 2: CATEGORY BREAKDOWN (Sales & Margin %)
    function renderCategoryChart(data) {{
      const ctx = document.getElementById('chartCategory').getContext('2d');
      if (state.charts.category) state.charts.category.destroy();

      const catMap = new Map();
      data.forEach(r => {{
        if (!catMap.has(r.category)) catMap.set(r.category, {{ sales: 0, profit: 0 }});
        const c = catMap.get(r.category);
        c.sales += r.sales;
        c.profit += r.profit;
      }});

      // Sort categories descending by Sales
      const sortedCats = Array.from(catMap.keys()).sort((a, b) => catMap.get(b).sales - catMap.get(a).sales);
      const salesArr = sortedCats.map(k => Math.round(catMap.get(k).sales));
      const marginArr = sortedCats.map(k => {{
        const s = catMap.get(k).sales;
        const p = catMap.get(k).profit;
        return s > 0 ? Number(((p / s) * 100).toFixed(1)) : 0;
      }});

      state.charts.category = new Chart(ctx, {{
        type: 'bar',
        data: {{
          labels: sortedCats,
          datasets: [
            {{
              type: 'line',
              label: 'Profit Margin %',
              data: marginArr,
              borderColor: '#0d9488',
              backgroundColor: '#0d9488',
              borderWidth: 2,
              pointRadius: 4,
              yAxisID: 'yMargin',
              order: 1
            }},
            {{
              type: 'bar',
              label: 'Net Sales ($)',
              data: salesArr,
              backgroundColor: state.theme === 'dark' ? 'rgba(56, 189, 248, 0.7)' : 'rgba(2, 132, 199, 0.75)',
              hoverBackgroundColor: state.theme === 'dark' ? '#38bdf8' : '#0284c7',
              borderRadius: 4,
              maxBarThickness: 38,
              yAxisID: 'ySales',
              order: 2
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          interaction: {{ mode: 'index', intersect: false }},
          plugins: {{
            legend: {{
              position: 'top',
              align: 'end',
              labels: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), usePointStyle: true, boxWidth: 8 }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                label: (ctx) => ctx.dataset.type === 'line' ? `Margin: ${{ctx.parsed.y}}%` : `Sales: ${{fmtCurrency(ctx.parsed.y)}}`
              }}
            }}
          }},
          scales: {{
            x: {{
              grid: {{ display: false }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor() }}
            }},
            ySales: {{
              position: 'left',
              title: {{ display: true, text: 'Sales ($)', color: chartTheme.getTextColor(), font: chartTheme.getFont() }},
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), callback: val => '$' + (val / 1000) + 'k' }}
            }},
            yMargin: {{
              position: 'right',
              title: {{ display: true, text: 'Margin (%)', color: '#0d9488', font: chartTheme.getFont() }},
              grid: {{ drawOnChartArea: false }},
              ticks: {{ font: chartTheme.getFont(), color: '#0d9488', callback: val => val + '%' }},
              suggestedMin: 20,
              suggestedMax: 40
            }}
          }}
        }}
      }});
    }}

    // CHART 3: REGIONAL PERFORMANCE (Sales & Profit)
    function renderRegionChart(data) {{
      const ctx = document.getElementById('chartRegion').getContext('2d');
      if (state.charts.region) state.charts.region.destroy();

      const regMap = new Map();
      const regions = ['Central', 'North', 'South', 'West'];
      regions.forEach(r => regMap.set(r, {{ sales: 0, profit: 0 }}));

      data.forEach(r => {{
        if (regMap.has(r.region)) {{
          const entry = regMap.get(r.region);
          entry.sales += r.sales;
          entry.profit += r.profit;
        }}
      }});

      // Sort by Sales descending
      const sortedRegions = regions.sort((a, b) => regMap.get(b).sales - regMap.get(a).sales);
      const salesArr = sortedRegions.map(r => Math.round(regMap.get(r).sales));
      const profitArr = sortedRegions.map(r => Math.round(regMap.get(r).profit));
      const marginArr = sortedRegions.map(r => {{
        const s = regMap.get(r).sales;
        const p = regMap.get(r).profit;
        return s > 0 ? ((p / s) * 100).toFixed(1) : '0.0';
      }});

      state.charts.region = new Chart(ctx, {{
        type: 'bar',
        data: {{
          labels: sortedRegions,
          datasets: [
            {{
              label: 'Sales ($)',
              data: salesArr,
              backgroundColor: state.theme === 'dark' ? '#38bdf8' : '#0284c7',
              borderRadius: 4,
              maxBarThickness: 30
            }},
            {{
              label: 'Profit ($)',
              data: profitArr,
              backgroundColor: '#10b981',
              borderRadius: 4,
              maxBarThickness: 30
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          interaction: {{ mode: 'index', intersect: false }},
          plugins: {{
            legend: {{
              position: 'top',
              align: 'end',
              labels: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), usePointStyle: true, boxWidth: 8 }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                afterBody: (items) => {{
                  const idx = items[0].dataIndex;
                  return `Profit Margin: ${{marginArr[idx]}}%`;
                }},
                label: (ctx) => `${{ctx.dataset.label}}: ${{fmtCurrency(ctx.parsed.y)}}`
              }}
            }}
          }},
          scales: {{
            x: {{
              grid: {{ display: false }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor() }}
            }},
            y: {{
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), callback: val => '$' + (val / 1000) + 'k' }}
            }}
          }}
        }}
      }});
    }}

    // CHART 4: BRAND COMPARISON (Apple vs Dell vs HP)
    function renderBrandChart(data) {{
      const ctx = document.getElementById('chartBrand').getContext('2d');
      if (state.charts.brand) state.charts.brand.destroy();

      const brandMap = new Map();
      const brands = ['Apple', 'Dell', 'HP'];
      brands.forEach(b => brandMap.set(b, {{ sales: 0, profit: 0 }}));

      data.forEach(r => {{
        if (brandMap.has(r.brand)) {{
          const entry = brandMap.get(r.brand);
          entry.sales += r.sales;
          entry.profit += r.profit;
        }}
      }});

      const totalSales = data.reduce((acc, r) => acc + r.sales, 0);
      const salesArr = brands.map(b => Math.round(brandMap.get(b).sales));
      const profitArr = brands.map(b => Math.round(brandMap.get(b).profit));
      const marginArr = brands.map(b => {{
        const s = brandMap.get(b).sales;
        const p = brandMap.get(b).profit;
        return s > 0 ? Number(((p / s) * 100).toFixed(1)) : 0;
      }});
      const shareArr = brands.map(b => {{
        const s = brandMap.get(b).sales;
        return totalSales > 0 ? ((s / totalSales) * 100).toFixed(1) : '0.0';
      }});

      state.charts.brand = new Chart(ctx, {{
        type: 'bar',
        data: {{
          labels: brands,
          datasets: [
            {{
              type: 'line',
              label: 'Profit Margin %',
              data: marginArr,
              borderColor: '#8b5cf6',
              backgroundColor: '#8b5cf6',
              borderWidth: 2.5,
              pointRadius: 4.5,
              yAxisID: 'yMargin',
              order: 1
            }},
            {{
              type: 'bar',
              label: 'Sales Revenue ($)',
              data: salesArr,
              backgroundColor: state.theme === 'dark' ? 'rgba(56, 189, 248, 0.7)' : 'rgba(2, 132, 199, 0.75)',
              hoverBackgroundColor: state.theme === 'dark' ? '#38bdf8' : '#0284c7',
              borderRadius: 4,
              maxBarThickness: 38,
              yAxisID: 'ySales',
              order: 2
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          interaction: {{ mode: 'index', intersect: false }},
          plugins: {{
            legend: {{
              position: 'top',
              align: 'end',
              labels: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), usePointStyle: true, boxWidth: 8 }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                afterBody: (items) => {{
                  const idx = items[0].dataIndex;
                  return `Revenue Share: ${{shareArr[idx]}}% | Profit: ${{fmtCurrency(profitArr[idx])}}`;
                }},
                label: (ctx) => ctx.dataset.type === 'line' ? `Margin: ${{ctx.parsed.y}}%` : `Sales: ${{fmtCurrency(ctx.parsed.y)}}`
              }}
            }}
          }},
          scales: {{
            x: {{
              grid: {{ display: false }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor() }}
            }},
            ySales: {{
              position: 'left',
              title: {{ display: true, text: 'Sales ($)', color: chartTheme.getTextColor(), font: chartTheme.getFont() }},
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), callback: val => '$' + (val / 1000) + 'k' }}
            }},
            yMargin: {{
              position: 'right',
              title: {{ display: true, text: 'Margin (%)', color: '#8b5cf6', font: chartTheme.getFont() }},
              grid: {{ drawOnChartArea: false }},
              ticks: {{ font: chartTheme.getFont(), color: '#8b5cf6', callback: val => val + '%' }},
              suggestedMin: 25,
              suggestedMax: 36
            }}
          }}
        }}
      }});
    }}

    // CHART 5: TOP 10 PRODUCTS OR SALES REPS (Horizontal Ranking)
    function renderTop10Chart(data) {{
      const ctx = document.getElementById('chartTop10').getContext('2d');
      if (state.charts.top10) state.charts.top10.destroy();

      const rankBy = state.rankingType === 'products' ? 'productName' : 'salesPerson';
      const aggMap = new Map();

      data.forEach(r => {{
        const key = r[rankBy];
        if (!aggMap.has(key)) aggMap.set(key, {{ label: key, sales: 0, profit: 0, orders: 0 }});
        const entry = aggMap.get(key);
        entry.sales += r.sales;
        entry.profit += r.profit;
        entry.orders += 1;
      }});

      // Top 10 sorted by Sales
      const sorted = Array.from(aggMap.values())
        .sort((a, b) => b.sales - a.sales)
        .slice(0, 10);

      // Invert for horizontal bar so #1 is at top
      sorted.reverse();

      const labels = sorted.map(item => item.label);
      const salesArr = sorted.map(item => Math.round(item.sales));
      const profitArr = sorted.map(item => Math.round(item.profit));

      // Dynamic callout
      if (sorted.length > 0) {{
        const leader = sorted[sorted.length - 1]; // highest
        if (state.rankingType === 'products') {{
          document.getElementById('rankingCalloutText').innerHTML = `💡 <strong>SKU Leader:</strong> ${{leader.label}} leads with ${{fmtCurrency(leader.sales)}} Sales and ${{fmtCurrency(leader.profit)}} Profit.`;
        }} else {{
          document.getElementById('rankingCalloutText').innerHTML = `💡 <strong>Top Rep:</strong> ${{leader.label}} leads with ${{fmtCurrency(leader.sales)}} Sales across ${{leader.orders}} orders.`;
        }}
      }}

      state.charts.top10 = new Chart(ctx, {{
        type: 'bar',
        data: {{
          labels: labels,
          datasets: [
            {{
              label: 'Profit ($)',
              data: profitArr,
              backgroundColor: '#10b981',
              borderRadius: 3,
              maxBarThickness: 14
            }},
            {{
              label: 'Sales ($)',
              data: salesArr,
              backgroundColor: state.theme === 'dark' ? '#38bdf8' : '#0284c7',
              borderRadius: 3,
              maxBarThickness: 14
            }}
          ]
        }},
        options: {{
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          interaction: {{ mode: 'index', intersect: false }},
          plugins: {{
            legend: {{
              position: 'top',
              align: 'end',
              labels: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), usePointStyle: true, boxWidth: 8 }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                afterBody: (items) => {{
                  const idx = items[0].dataIndex;
                  const item = sorted[idx];
                  const m = item.sales > 0 ? ((item.profit / item.sales) * 100).toFixed(1) : '0.0';
                  return `Margin: ${{m}}% | Orders: ${{item.orders}}`;
                }},
                label: (ctx) => `${{ctx.dataset.label}}: ${{fmtCurrency(ctx.parsed.x)}}`
              }}
            }}
          }},
          scales: {{
            x: {{
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), callback: val => '$' + (val / 1000) + 'k' }}
            }},
            y: {{
              grid: {{ display: false }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor() }}
            }}
          }}
        }}
      }});
    }}

    // CHART 6: DISCOUNT % VS PROFIT MARGIN % SCATTER PLOT
    function renderScatterChart(data) {{
      const ctx = document.getElementById('chartScatter').getContext('2d');
      if (state.charts.scatter) state.charts.scatter.destroy();

      const scatterData = data.map(r => ({{
        x: r.discount,
        y: r.profitMargin,
        orderId: r.orderId,
        product: r.productName,
        sales: r.sales,
        profit: r.profit
      }}));

      // Calculate Pearson r and regression line
      const rVal = calculatePearsonCorrelation(data);
      const {{ slope, intercept }} = calculateLinearRegression(data);

      const rBadge = document.getElementById('corrBadge');
      rBadge.textContent = `r = ${{rVal.toFixed(4)}} (${{Math.abs(rVal) > 0.4 ? 'Moderate Negative' : 'Weak Correlation'}})`;

      // Regression line points (from min discount 0% to max 20%)
      const trendlineData = [
        {{ x: 0, y: Number(intercept.toFixed(2)) }},
        {{ x: 20, y: Number(((slope * 20) + intercept).toFixed(2)) }}
      ];

      state.charts.scatter = new Chart(ctx, {{
        type: 'scatter',
        data: {{
          datasets: [
            {{
              label: 'Transactions',
              data: scatterData,
              backgroundColor: state.theme === 'dark' ? 'rgba(56, 189, 248, 0.4)' : 'rgba(2, 132, 199, 0.4)',
              borderColor: state.theme === 'dark' ? '#38bdf8' : '#0284c7',
              borderWidth: 1,
              pointRadius: 4,
              pointHoverRadius: 6
            }},
            {{
              type: 'line',
              label: `Trendline (y = ${{slope.toFixed(2)}}x + ${{intercept.toFixed(1)}})`,
              data: trendlineData,
              borderColor: '#ef4444',
              borderWidth: 2,
              borderDash: [5, 5],
              fill: false,
              pointRadius: 0
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {{
            legend: {{
              position: 'top',
              align: 'end',
              labels: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), usePointStyle: true, boxWidth: 8 }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                label: function(ctx) {{
                  if (ctx.dataset.type === 'line') return `Trendline: Margin = ${{ctx.parsed.y}}%`;
                  const p = ctx.raw;
                  return [
                    `Order: ${{p.orderId}} (${{p.product}})`,
                    `Discount: ${{p.x}}% | Margin: ${{p.y}}%`,
                    `Sales: ${{fmtCurrency(p.sales)}} | Profit: ${{fmtCurrency(p.profit)}}`
                  ];
                }}
              }}
            }}
          }},
          scales: {{
            x: {{
              title: {{ display: true, text: 'Discount Applied (%)', color: chartTheme.getTextColor(), font: chartTheme.getFont() }},
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), callback: v => v + '%' }},
              min: -1,
              max: 22
            }},
            y: {{
              title: {{ display: true, text: 'Profit Margin (%)', color: chartTheme.getTextColor(), font: chartTheme.getFont() }},
              grid: {{ color: chartTheme.getGridColor() }},
              ticks: {{ font: chartTheme.getFont(), color: chartTheme.getTextColor(), callback: v => v + '%' }}
            }}
          }}
        }}
      }});
    }}

    // CHART 7: OPERATIONAL HEALTH (Doughnut Breakdown)
    function renderOperationsChart(data) {{
      const ctx = document.getElementById('chartOperations').getContext('2d');
      if (state.charts.operations) state.charts.operations.destroy();

      const sliceField = state.opsSlice;
      const countMap = new Map();
      data.forEach(r => {{
        const val = r[sliceField];
        countMap.set(val, (countMap.get(val) || 0) + 1);
      }});

      const labels = Array.from(countMap.keys());
      const counts = labels.map(l => countMap.get(l));
      const total = counts.reduce((a, b) => a + b, 0);

      // Color palettes per slice
      let bgColors = [];
      if (sliceField === 'orderStatus') {{
        bgColors = labels.map(l => {{
          if (l === 'Completed') return '#10b981';
          if (l === 'Shipped') return '#3b82f6';
          return '#f59e0b';
        }});
        document.getElementById('opsCalloutText').innerHTML = `📦 <strong>Fulfillment Status:</strong> ${{countMap.get('Completed') || 0}} Completed, ${{countMap.get('Shipped') || 0}} Shipped, ${{countMap.get('Pending') || 0}} Pending.`;
      }} else if (sliceField === 'paymentMode') {{
        bgColors = labels.map(l => {{
          if (l === 'Credit Card') return '#6366f1';
          if (l === 'UPI') return '#0d9488';
          return '#f97316';
        }});
        document.getElementById('opsCalloutText').innerHTML = `💳 <strong>Payment Mix:</strong> Credit Card represents largest payment share with ${{countMap.get('Credit Card') || 0}} orders.`;
      }} else {{
        bgColors = labels.map(l => l.toLowerCase() === 'yes' ? '#ef4444' : '#10b981');
        const retCount = countMap.get('Yes') || 0;
        const retPct = total > 0 ? ((retCount / total) * 100).toFixed(1) : '0.0';
        document.getElementById('opsCalloutText').innerHTML = `⚠️ <strong>Return Audit:</strong> ${{retCount}} orders (${{retPct}}%) returned out of ${{total}} transactions.`;
      }}

      state.charts.operations = new Chart(ctx, {{
        type: 'doughnut',
        data: {{
          labels: labels,
          datasets: [{{
            data: counts,
            backgroundColor: bgColors,
            borderColor: state.theme === 'dark' ? '#131c2e' : '#ffffff',
            borderWidth: 2,
            hoverOffset: 6
          }}]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          cutout: '68%',
          plugins: {{
            legend: {{
              position: 'right',
              labels: {{
                font: chartTheme.getFont(),
                color: chartTheme.getTextColor(),
                usePointStyle: true,
                pointStyle: 'circle',
                boxWidth: 8,
                padding: 14,
                generateLabels: function(chart) {{
                  const original = Chart.overrides.doughnut.plugins.legend.labels.generateLabels(chart);
                  return original.map(item => {{
                    const count = counts[item.index];
                    const pct = total > 0 ? ((count / total) * 100).toFixed(1) : 0;
                    item.text = `${{item.text}}: ${{count}} (${{pct}}%)`;
                    return item;
                  }});
                }}
              }}
            }},
            tooltip: {{
              ...chartTheme.getTooltipTheme(),
              callbacks: {{
                label: (ctx) => {{
                  const c = ctx.parsed;
                  const pct = total > 0 ? ((c / total) * 100).toFixed(1) : 0;
                  return `Count: ${{c}} orders (${{pct}}%)`;
                }}
              }}
            }}
          }}
        }}
      }});
    }}

    // 8. DYNAMIC EXECUTIVE STRATEGIC INSIGHTS GENERATOR
    function generateDynamicInsights(data) {{
      const grid = document.getElementById('insightsGrid');
      if (!data || data.length === 0) {{
        grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:30px;color:var(--text-muted);">No records in active scope to generate strategic observations.</div>';
        return;
      }}

      const insights = [];
      const totalSales = data.reduce((a, r) => a + r.sales, 0);
      const totalProfit = data.reduce((a, r) => a + r.profit, 0);
      const overallMargin = totalSales > 0 ? (totalProfit / totalSales) * 100 : 0;
      const totalOrders = data.length;

      // Insight 1: Macro Growth & Trajectory (2024 vs 2023 vs 2025)
      const sales23 = data.filter(r => r.year === 2023).reduce((a, r) => a + r.sales, 0);
      const sales24 = data.filter(r => r.year === 2024).reduce((a, r) => a + r.sales, 0);
      const sales25 = data.filter(r => r.year === 2025).reduce((a, r) => a + r.sales, 0);

      // Equivalent 4-month comparison (Jan-Apr 2024 vs Jan-Apr 2025)
      const eq24 = RAW_DATA.filter(r => r.year === 2024 && r.monthNo <= 4).reduce((a, r) => a + r.sales, 0);
      const eq25 = RAW_DATA.filter(r => r.year === 2025 && r.monthNo <= 4).reduce((a, r) => a + r.sales, 0);
      const eqGrowth = eq24 > 0 ? ((eq25 - eq24) / eq24) * 100 : 0;

      insights.push({{
        tag: 'Growth Momentum',
        tagClass: 'tag-growth',
        metric: `+${{eqGrowth.toFixed(1)}}% Equivalent YoY`,
        title: '2025 Annualized Run-Rate Shows Strong Underlying Velocity',
        body: `Full-year 2024 sales ($900.6K) surged 41.6% over 2023 ($636.1K). While raw 2025 volume ($399.6K) appears lower, it reflects only 4 months (Jan–Apr). On an equivalent period basis, Jan–Apr 2025 grew +${{eqGrowth.toFixed(1)}}% over Jan–Apr 2024 ($214.0K), indicating accelerating top-line momentum.`,
        recommendation: 'Executive Action: Do not mistake partial-year 2025 figures for a structural slowdown. Audit inventory procurement and working capital to support 80%+ annualized expansion.'
      }});

      // Insight 2: High Return Rate Risk
      const returnOrders = data.filter(r => r.returnStatus.toLowerCase() === 'yes');
      const returnRate = (returnOrders.length / totalOrders) * 100;
      // Category with highest returns
      const catReturnMap = new Map();
      data.forEach(r => {{
        if (!catReturnMap.has(r.category)) catReturnMap.set(r.category, {{ total: 0, ret: 0 }});
        const c = catReturnMap.get(r.category);
        c.total += 1;
        if (r.returnStatus.toLowerCase() === 'yes') c.ret += 1;
      }});
      let worstCat = '', worstCatRate = 0;
      catReturnMap.forEach((val, cat) => {{
        const rRate = val.total > 0 ? (val.ret / val.total) * 100 : 0;
        if (rRate > worstCatRate && val.total >= 5) {{
          worstCatRate = rRate;
          worstCat = cat;
        }}
      }});

      insights.push({{
        tag: 'Operational Risk',
        tagClass: 'tag-risk',
        metric: `${{returnRate.toFixed(1)}}% Return Rate`,
        title: 'Alarming Return Rate Represents Material Margin Leakage',
        body: `Approximately 1 out of every 2 customer orders (${{returnOrders.length}} of ${{totalOrders}}) is returned, far above healthy retail thresholds (typically 8–15%). ${{worstCat}} exhibits the highest return rate at ${{worstCatRate.toFixed(1)}}%. This causes severe friction, reverse logistics freight costs, and inventory write-downs.`,
        recommendation: 'Management Question: Mandate an immediate cross-functional audit with QA, supply chain, and customer service to isolate root causes (misleading specs, packaging damage, or sizing/compatibility defect).'
      }});

      // Insight 3: Margin Disparity across Categories (Electronics vs Furniture)
      const catStats = [];
      const catMap = new Map();
      data.forEach(r => {{
        if (!catMap.has(r.category)) catMap.set(r.category, {{ sales: 0, profit: 0 }});
        const c = catMap.get(r.category);
        c.sales += r.sales;
        c.profit += r.profit;
      }});
      catMap.forEach((v, k) => {{
        const m = v.sales > 0 ? (v.profit / v.sales) * 100 : 0;
        catStats.push({{ cat: k, sales: v.sales, profit: v.profit, margin: m }});
      }});
      catStats.sort((a, b) => b.sales - a.sales);
      const topSalesCat = catStats[0] || {{ cat: 'Electronics', sales: 0, margin: 0 }};
      const topMarginCat = [...catStats].sort((a, b) => b.margin - a.margin)[0] || {{ cat: 'Furniture', margin: 0 }};

      insights.push({{
        tag: 'Profitability Mix',
        tagClass: 'tag-opportunity',
        metric: `${{topMarginCat.cat}}: ${{topMarginCat.margin.toFixed(1)}}% Margin`,
        title: `Volume Leader (${{topSalesCat.cat}}) ≠ Margin Champion (${{topMarginCat.cat}})`,
        body: `${{topSalesCat.cat}} accounts for the highest gross sales volume (${{fmtCurrency(topSalesCat.sales)}}), but generates a modest ${{topSalesCat.margin.toFixed(1)}}% margin. In contrast, ${{topMarginCat.cat}} yields the enterprise's highest profit margin at ${{topMarginCat.margin.toFixed(1)}}% (${{fmtCurrency(topMarginCat.profit)}} profit).`,
        recommendation: 'Strategic Directive: Shift digital advertising budgets, promotional placement, and sales rep commission incentives toward ${{topMarginCat.cat}} and high-yield accessory bundles to boost blended margins.'
      }});

      // Insight 4: Brand Performance & Vendor Margin Power
      const brandMap = new Map();
      data.forEach(r => {{
        if (!brandMap.has(r.brand)) brandMap.set(r.brand, {{ sales: 0, profit: 0 }});
        const b = brandMap.get(r.brand);
        b.sales += r.sales;
        b.profit += r.profit;
      }});
      const dell = brandMap.get('Dell') || {{ sales: 0, profit: 0 }};
      const apple = brandMap.get('Apple') || {{ sales: 0, profit: 0 }};
      const dellMargin = dell.sales > 0 ? (dell.profit / dell.sales) * 100 : 0;
      const appleMargin = apple.sales > 0 ? (apple.profit / apple.sales) * 100 : 0;

      insights.push({{
        tag: 'Brand Economics',
        tagClass: 'tag-strategy',
        metric: `Dell: ${{dellMargin.toFixed(1)}}% vs Apple: ${{appleMargin.toFixed(1)}}%`,
        title: 'Dell Generates Superior Margin Spread Over Apple and HP',
        body: `Dell achieves the strongest profit margin (${{dellMargin.toFixed(1)}}%), delivering ${{fmtCurrency(dell.profit)}} in profit. Despite Apple's high brand prestige and customer order interest, its net margin is compressed to ${{appleMargin.toFixed(1)}}%, driven by tighter wholesale price structures and aggressive price discounting.`,
        recommendation: 'Commercial Tactic: Steer enterprise B2B volume purchasing toward Dell configurations, while renegotiating tier-1 co-op vendor allowances with Apple and HP.'
      }});

      // Insight 5: Regional Territory Asymmetry (North Opportunity vs West Dominance)
      const regMap = new Map();
      data.forEach(r => {{
        if (!regMap.has(r.region)) regMap.set(r.region, {{ sales: 0, profit: 0 }});
        const reg = regMap.get(r.region);
        reg.sales += r.sales;
        reg.profit += r.profit;
      }});
      const west = regMap.get('West') || {{ sales: 0, profit: 0 }};
      const north = regMap.get('North') || {{ sales: 0, profit: 0 }};
      const northMargin = north.sales > 0 ? (north.profit / north.sales) * 100 : 0;

      insights.push({{
        tag: 'Territory Upside',
        tagClass: 'tag-opportunity',
        metric: `North: ${{northMargin.toFixed(1)}}% Margin Leader`,
        title: 'North Region Demonstrates Untapped High-Margin Expansion Upside',
        body: `The West region commands the largest revenue footprint (${{fmtCurrency(west.sales)}}), but North achieves the highest profitability rate across all 4 territories at ${{northMargin.toFixed(1)}}% margin, despite currently having the lowest transaction count.`,
        recommendation: 'Market Expansion: North customers exhibit low price sensitivity and healthy willingness to pay. Allocate additional dedicated field sales reps to North territories to capture latent demand.'
      }});

      // Insight 6: Discount Governance & Margin Erosion
      const corr = calculatePearsonCorrelation(data);
      const heavyDiscountOrders = data.filter(r => r.discount >= 15);
      const heavyDiscountSales = heavyDiscountOrders.reduce((a, r) => a + r.sales, 0);

      insights.push({{
        tag: 'Pricing Policy',
        tagClass: 'tag-risk',
        metric: `r = ${{corr.toFixed(2)}} (Margin Drag)`,
        title: 'Deep Discounting Systematically Erodes Net Profitability',
        body: `Statistical regression confirms a statistically significant negative correlation (r = ${{corr.toFixed(2)}}) between Discount % and Profit Margin %. Orders granted discounts ≥15% (${{heavyDiscountOrders.length}} transactions totaling ${{fmtCurrency(heavyDiscountSales)}} in revenue) show no offsetting surge in order volume, effectively transferring margin directly to customers.`,
        recommendation: 'Policy Recommendation: Implement a formal discount matrix requiring VP approval for discounts above 10%. Stop uncompensated discounting on flagship electronics.'
      }});

      // Render cards
      grid.innerHTML = insights.map(item => `
        <div class="insight-card">
          <div class="insight-top-bar">
            <span class="insight-tag ${{item.tagClass}}">${{item.tag}}</span>
            <span class="insight-metric-pill">${{item.metric}}</span>
          </div>
          <h4 class="insight-title">${{item.title}}</h4>
          <p class="insight-body">${{item.body}}</p>
          <div class="insight-recommendation">
            <span class="rec-label">Strategic Recommendation</span>
            <span>${{item.recommendation}}</span>
          </div>
        </div>
      `).join('');
    }}

    // 9. TRANSACTION DETAIL TABLE (Sort, Search, Pagination, CSV Export)
    function renderTransactionTable(data) {{
      const t = state.table;
      let rows = [...data];

      // Table search filter
      if (t.searchTerm) {{
        const term = t.searchTerm.toLowerCase();
        rows = rows.filter(r => 
          r.orderId.toLowerCase().includes(term) ||
          r.customerName.toLowerCase().includes(term) ||
          r.productName.toLowerCase().includes(term) ||
          r.salesPerson.toLowerCase().includes(term) ||
          r.category.toLowerCase().includes(term) ||
          r.brand.toLowerCase().includes(term) ||
          r.region.toLowerCase().includes(term) ||
          r.orderStatus.toLowerCase().includes(term)
        );
      }}

      // Sorting
      rows.sort((a, b) => {{
        let valA = a[t.sortCol];
        let valB = b[t.sortCol];
        if (typeof valA === 'string') valA = valA.toLowerCase();
        if (typeof valB === 'string') valB = valB.toLowerCase();
        if (valA < valB) return t.sortAsc ? -1 : 1;
        if (valA > valB) return t.sortAsc ? 1 : -1;
        return 0;
      }});

      // Empty State
      const tbody = document.getElementById('tableBody');
      const emptyState = document.getElementById('tableEmptyState');
      if (rows.length === 0) {{
        tbody.innerHTML = '';
        emptyState.style.display = 'flex';
        document.getElementById('tableShowingText').textContent = 'Showing 0 of 0 entries';
        document.getElementById('paginationControls').innerHTML = '';
        return;
      }}
      emptyState.style.display = 'none';

      // Pagination slice
      const totalEntries = rows.length;
      const totalPages = Math.ceil(totalEntries / t.pageSize);
      if (t.page > totalPages) t.page = totalPages;
      if (t.page < 1) t.page = 1;

      const startIdx = (t.page - 1) * t.pageSize;
      const endIdx = Math.min(startIdx + t.pageSize, totalEntries);
      const pageRows = rows.slice(startIdx, endIdx);

      // Render Rows
      tbody.innerHTML = pageRows.map(r => `
        <tr>
          <td><strong style="font-family:var(--font-mono);">${{r.orderId}}</strong></td>
          <td>${{r.orderDate}}</td>
          <td>${{r.customerName}}</td>
          <td><strong>${{r.productName}}</strong></td>
          <td>${{r.category}}</td>
          <td>${{r.brand}}</td>
          <td>${{r.region}}</td>
          <td>${{r.salesPerson}}</td>
          <td style="text-align:right;font-weight:600;">${{fmtCurrencyDecimal(r.sales)}}</td>
          <td style="text-align:right;font-weight:600;color:#10b981;">${{fmtCurrencyDecimal(r.profit)}}</td>
          <td style="text-align:right;font-family:var(--font-mono);">${{fmtPct(r.profitMargin)}}</td>
          <td><span class="status-badge status-${{r.orderStatus.toLowerCase()}}">${{r.orderStatus}}</span></td>
          <td><span class="status-badge status-returned-${{r.returnStatus.toLowerCase()}}">${{r.returnStatus}}</span></td>
        </tr>
      `).join('');

      document.getElementById('tableShowingText').textContent = 
        `Showing ${{startIdx + 1}} to ${{endIdx}} of ${{totalEntries}} entries`;

      // Render Pagination Buttons
      renderPaginationControls(totalPages, t.page);
    }}

    function renderPaginationControls(totalPages, currentPage) {{
      const container = document.getElementById('paginationControls');
      if (totalPages <= 1) {{
        container.innerHTML = '';
        return;
      }}

      let html = `
        <button type="button" class="page-btn" ${{currentPage === 1 ? 'disabled' : ''}} onclick="changeTablePage(${{currentPage - 1}})">Prev</button>
      `;

      const maxBtns = 5;
      let startPage = Math.max(1, currentPage - 2);
      let endPage = Math.min(totalPages, startPage + maxBtns - 1);
      if (endPage - startPage < maxBtns - 1) {{
        startPage = Math.max(1, endPage - maxBtns + 1);
      }}

      for (let p = startPage; p <= endPage; p++) {{
        html += `
          <button type="button" class="page-btn ${{p === currentPage ? 'active' : ''}}" onclick="changeTablePage(${{p}})">${{p}}</button>
        `;
      }}

      html += `
        <button type="button" class="page-btn" ${{currentPage === totalPages ? 'disabled' : ''}} onclick="changeTablePage(${{currentPage + 1}})">Next</button>
      `;
      container.innerHTML = html;
    }}

    function changeTablePage(p) {{
      state.table.page = p;
      renderTransactionTable(getFilteredData());
    }}

    // Export Filtered Table to CSV
    function exportTableToCSV() {{
      const data = getFilteredData();
      if (!data || data.length === 0) {{
        alert('No records available to export.');
        return;
      }}

      const headers = ['Order ID', 'Order Date', 'Customer Name', 'Product Name', 'Category', 'Brand', 'Region', 'State', 'City', 'Sales Person', 'Quantity', 'Unit Price', 'Discount %', 'Sales', 'Profit', 'Profit Margin %', 'Order Status', 'Payment Mode', 'Return Status'];
      
      const csvRows = [];
      csvRows.push(headers.join(','));

      data.forEach(r => {{
        const row = [
          `"${{r.orderId}}"`,
          `"${{r.orderDate}}"`,
          `"${{r.customerName.replace(/"/g, '""')}}"`,
          `"${{r.productName.replace(/"/g, '""')}}"`,
          `"${{r.category}}"`,
          `"${{r.brand}}"`,
          `"${{r.region}}"`,
          `"${{r.state}}"`,
          `"${{r.city}}"`,
          `"${{r.salesPerson}}"`,
          r.quantity,
          r.unitPrice,
          r.discount,
          r.sales,
          r.profit,
          r.profitMargin,
          `"${{r.orderStatus}}"`,
          `"${{r.paymentMode}}"`,
          `"${{r.returnStatus}}"`
        ];
        csvRows.push(row.join(','));
      }});

      const blob = new Blob([csvRows.join('\\n')], {{ type: 'text/csv;charset=utf-8;' }});
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `Executive_Sales_Dataset_Export_${{new Date().toISOString().split('T')[0]}}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }}

    // 10. REFRESH CONTROLLER
    function refreshDashboard() {{
      const data = getFilteredData();
      const kpis = calculateKPIs(data);

      updateKPICards(kpis);
      updateActiveChipsBar(data.length);
      renderTrendChart(data);
      renderCategoryChart(data);
      renderRegionChart(data);
      renderBrandChart(data);
      renderTop10Chart(data);
      renderScatterChart(data);
      renderOperationsChart(data);
      generateDynamicInsights(data);
      renderTransactionTable(data);
    }}

    // 11. INITIALIZATION & EVENT LISTENERS
    function populateSalesReps() {{
      const reps = Array.from(new Set(RAW_DATA.map(r => r.salesPerson))).sort();
      const listEl = document.getElementById('repDropdownList');
      listEl.innerHTML = `
        <div class="rep-item ${{!state.filters.salesPerson ? 'selected' : ''}}" data-val="">(All Sales Reps)</div>
      ` + reps.map(r => `
        <div class="rep-item ${{state.filters.salesPerson === r ? 'selected' : ''}}" data-val="${{r}}">${{r}}</div>
      `).join('');

      const searchInput = document.getElementById('salesRepSearch');

      searchInput.addEventListener('focus', () => {{
        listEl.classList.add('show');
      }});

      searchInput.addEventListener('input', (e) => {{
        const q = e.target.value.toLowerCase();
        listEl.querySelectorAll('.rep-item').forEach(item => {{
          const txt = item.textContent.toLowerCase();
          item.style.display = txt.includes(q) ? 'flex' : 'none';
        }});
        listEl.classList.add('show');
      }});

      listEl.addEventListener('click', (e) => {{
        const item = e.target.closest('.rep-item');
        if (!item) return;
        const val = item.getAttribute('data-val');
        state.filters.salesPerson = val;
        searchInput.value = val ? val : '';
        listEl.querySelectorAll('.rep-item').forEach(el => el.classList.remove('selected'));
        item.classList.add('selected');
        listEl.classList.remove('show');
        refreshDashboard();
      }});

      document.addEventListener('click', (e) => {{
        if (!e.target.closest('.custom-select-wrapper')) {{
          listEl.classList.remove('show');
        }}
      }});
    }}

    function setupEventListeners() {{
      // Global Search
      const searchInput = document.getElementById('searchGlobal');
      let debounceTimer = null;
      searchInput.addEventListener('input', (e) => {{
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {{
          state.filters.search = e.target.value;
          refreshDashboard();
        }}, 250);
      }});

      // Year Filter Buttons
      document.getElementById('filterYears').addEventListener('click', (e) => {{
        const btn = e.target.closest('.pill-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        state.filters.year = val;
        updatePillUI('filterYears', val);
        refreshDashboard();
      }});

      // Quarter Filter Multi-Select
      document.getElementById('filterQuarters').addEventListener('click', (e) => {{
        const btn = e.target.closest('.pill-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        toggleArrayFilter(state.filters.quarters, val);
        btn.classList.toggle('active');
        refreshDashboard();
      }});

      // Date Range Pickers
      document.getElementById('filterDateStart').addEventListener('change', (e) => {{
        state.filters.dateStart = e.target.value;
        refreshDashboard();
      }});
      document.getElementById('filterDateEnd').addEventListener('change', (e) => {{
        state.filters.dateEnd = e.target.value;
        refreshDashboard();
      }});

      // Region Filter Multi-Select
      document.getElementById('filterRegions').addEventListener('click', (e) => {{
        const btn = e.target.closest('.pill-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        toggleArrayFilter(state.filters.regions, val);
        btn.classList.toggle('active');
        refreshDashboard();
      }});

      // Category Filter Multi-Select
      document.getElementById('filterCategories').addEventListener('click', (e) => {{
        const btn = e.target.closest('.pill-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        toggleArrayFilter(state.filters.categories, val);
        btn.classList.toggle('active');
        refreshDashboard();
      }});

      // Brand Filter Multi-Select
      document.getElementById('filterBrands').addEventListener('click', (e) => {{
        const btn = e.target.closest('.pill-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        toggleArrayFilter(state.filters.brands, val);
        btn.classList.toggle('active');
        refreshDashboard();
      }});

      // Order Status Multi-Select
      document.getElementById('filterOrderStatus').addEventListener('click', (e) => {{
        const btn = e.target.closest('.pill-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        toggleArrayFilter(state.filters.orderStatuses, val);
        btn.classList.toggle('active');
        refreshDashboard();
      }});

      // Return Status Segmented Control
      document.getElementById('filterReturnStatus').addEventListener('click', (e) => {{
        const btn = e.target.closest('.seg-btn');
        if (!btn) return;
        const val = btn.getAttribute('data-val');
        state.filters.returnStatus = val;
        updateSegUI('filterReturnStatus', val);
        refreshDashboard();
      }});

      // Reset Buttons
      document.getElementById('btnResetFilters').addEventListener('click', resetAllFilters);
      document.getElementById('btnQuickReset').addEventListener('click', resetAllFilters);

      // Trend Granularity Toggles (Monthly / Quarterly / Yearly)
      document.querySelectorAll('[data-trend-grain]').forEach(btn => {{
        btn.addEventListener('click', (e) => {{
          document.querySelectorAll('[data-trend-grain]').forEach(b => b.classList.remove('active'));
          e.target.classList.add('active');
          state.trendGrain = e.target.getAttribute('data-trend-grain');
          renderTrendChart(getFilteredData());
        }});
      }});

      // Top 10 Ranking Toggle (Products vs Sales Reps)
      document.getElementById('btnRankProducts').addEventListener('click', (e) => {{
        document.getElementById('btnRankReps').classList.remove('active');
        e.target.classList.add('active');
        state.rankingType = 'products';
        document.getElementById('rankingTitleText').textContent = 'Top 10 Products by Revenue';
        renderTop10Chart(getFilteredData());
      }});
      document.getElementById('btnRankReps').addEventListener('click', (e) => {{
        document.getElementById('btnRankProducts').classList.remove('active');
        e.target.classList.add('active');
        state.rankingType = 'reps';
        document.getElementById('rankingTitleText').textContent = 'Top 10 Sales Reps by Revenue';
        renderTop10Chart(getFilteredData());
      }});

      // Operations Donut Slice Toggles
      document.querySelectorAll('[data-ops-slice]').forEach(btn => {{
        btn.addEventListener('click', (e) => {{
          document.querySelectorAll('[data-ops-slice]').forEach(b => b.classList.remove('active'));
          e.target.classList.add('active');
          state.opsSlice = e.target.getAttribute('data-ops-slice');
          renderOperationsChart(getFilteredData());
        }});
      }});

      // Table Search
      document.getElementById('tableFilterInput').addEventListener('input', (e) => {{
        state.table.searchTerm = e.target.value;
        state.table.page = 1;
        renderTransactionTable(getFilteredData());
      }});

      // Table Page Size
      document.getElementById('tablePageSize').addEventListener('change', (e) => {{
        state.table.pageSize = parseInt(e.target.value, 10);
        state.table.page = 1;
        renderTransactionTable(getFilteredData());
      }});

      // Table Column Sorting
      document.querySelectorAll('#transactionTable th[data-col]').forEach(th => {{
        th.addEventListener('click', () => {{
          const col = th.getAttribute('data-col');
          if (state.table.sortCol === col) {{
            state.table.sortAsc = !state.table.sortAsc;
          }} else {{
            state.table.sortCol = col;
            state.table.sortAsc = true;
          }}
          renderTransactionTable(getFilteredData());
        }});
      }});

      // Table Collapse Toggle
      const tableHeader = document.getElementById('tableHeaderBar');
      const tableBody = document.getElementById('tableCollapseBody');
      const tableIcon = document.getElementById('tableCollapseIcon');
      tableHeader.addEventListener('click', (e) => {{
        if (e.target.closest('#btnExportCSV')) return;
        const isHidden = tableBody.style.display === 'none';
        tableBody.style.display = isHidden ? 'block' : 'none';
        tableIcon.classList.toggle('collapsed', !isHidden);
      }});

      // Table Export CSV
      document.getElementById('btnExportCSV').addEventListener('click', exportTableToCSV);

      // Mobile Sidebar Toggle
      const mobileToggleBtn = document.getElementById('btnToggleMobileSidebar');
      const sidebar = document.getElementById('sidebar');
      mobileToggleBtn.addEventListener('click', () => {{
        sidebar.classList.toggle('open');
      }});

      // Theme Toggle (Light / Dark)
      const themeBtn = document.getElementById('btnThemeToggle');
      themeBtn.addEventListener('click', () => {{
        state.theme = state.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem('bi_dashboard_theme', state.theme);
        applyTheme(state.theme);
        refreshDashboard();
      }});
    }}

    function applyTheme(theme) {{
      document.documentElement.setAttribute('data-theme', theme);
      const label = document.getElementById('themeToggleLabel');
      label.textContent = theme === 'dark' ? 'Light Mode' : 'Dark Mode';
    }}

    function toggleArrayFilter(arr, val) {{
      const idx = arr.indexOf(val);
      if (idx > -1) arr.splice(idx, 1);
      else arr.push(val);
    }}

    function updatePillUI(containerId, activeVal) {{
      const cont = document.getElementById(containerId);
      cont.querySelectorAll('.pill-btn').forEach(btn => {{
        btn.classList.toggle('active', btn.getAttribute('data-val') === activeVal);
      }});
    }}

    function clearPillUI(containerId) {{
      const cont = document.getElementById(containerId);
      cont.querySelectorAll('.pill-btn').forEach(btn => btn.classList.remove('active'));
    }}

    function updateSegUI(containerId, activeVal) {{
      const cont = document.getElementById(containerId);
      cont.querySelectorAll('.seg-btn').forEach(btn => {{
        btn.classList.toggle('active', btn.getAttribute('data-val') === activeVal);
      }});
    }}

    function resetAllFilters() {{
      state.filters = {{
        search: '',
        year: 'ALL',
        quarters: [],
        dateStart: '',
        dateEnd: '',
        regions: [],
        categories: [],
        brands: [],
        salesPerson: '',
        orderStatuses: [],
        returnStatus: 'ALL'
      }};

      document.getElementById('searchGlobal').value = '';
      updatePillUI('filterYears', 'ALL');
      clearPillUI('filterQuarters');
      document.getElementById('filterDateStart').value = '';
      document.getElementById('filterDateEnd').value = '';
      clearPillUI('filterRegions');
      clearPillUI('filterCategories');
      clearPillUI('filterBrands');
      document.getElementById('salesRepSearch').value = '';
      clearPillUI('filterOrderStatus');
      updateSegUI('filterReturnStatus', 'ALL');

      state.table.page = 1;
      state.table.searchTerm = '';
      document.getElementById('tableFilterInput').value = '';

      refreshDashboard();
    }}

    // Kickoff on load
    window.addEventListener('DOMContentLoaded', () => {{
      applyTheme(state.theme);
      populateSalesReps();
      setupEventListeners();
      refreshDashboard();
    }});
  </script>
</body>
</html>
'''

import sys
import os
import pathlib
import webbrowser

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

file_path = pathlib.Path('index.html').resolve()
file_uri = file_path.as_uri()

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("=" * 72)
print(f"[OK] Berhasil membuat index.html ({len(html_content):,} karakter)")
print("=" * 72)
print("\n>>> LINK UNTUK MEMBUKA DASHBOARD (Ctrl + Klik link di bawah):")
print(f"    Link File   : {file_uri}")
print(f"    Link Server : http://localhost:8080/index.html")
print("\n>>> Path File:")
print(f"    {file_path}")
print("\nTips: Tahan tombol [Ctrl] lalu Klik salah satu link di atas untuk langsung membuka di browser.")
print("=" * 72)

# Buka otomatis di browser default
try:
    webbrowser.open(file_uri)
except Exception:
    pass

