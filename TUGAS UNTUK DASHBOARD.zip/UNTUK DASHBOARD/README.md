# Executive Sales & Profit Dashboard

An executive-grade, fully interactive Business Intelligence dashboard engineered for senior management and academic presentation. The dashboard provides an instant 5-second health read on enterprise commercial performance, followed by multi-dimensional drill-downs into product categories, regional territories, vendor brands, pricing/discounting discipline, operational fulfillment, and transaction-level audit records.

---

## 🚀 Quick Start Instructions

This dashboard is **100% self-contained** in a single file: [`index.html`](file:///d:/TUGAS%20KULIAH/SEMESTER%20V/AI/UNTUK%20DASHBOARD/index.html).

### Method 1: Direct File Launch (No Server Needed)
Simply double-click [`index.html`](file:///d:/TUGAS%20KULIAH/SEMESTER%20V/AI/UNTUK%20DASHBOARD/index.html) or right-click and open with your preferred browser (Google Chrome, Microsoft Edge, Mozilla Firefox, or Apple Safari). Once the CDN script loads, the file is fully operable offline.

### Method 2: Local HTTP Server (Optional)
If you prefer running via a local development server:
```bash
# Using Python 3 built-in server
python -m http.server 8080

# Then navigate to:
http://localhost:8080/index.html
```

---

## 📊 Dataset & Baseline Validation

- **Data Source**: `Ultimate_Sales_Profit_Dataset.xlsx` (Worksheet: `Data`)
- **Scope**: 500 transaction records spanning **May 3, 2023 to April 28, 2025**
- **Completeness**: 0 missing values; full 500 rows embedded directly into `index.html` as a structured JSON array. No external network requests transmit user data.

### Baseline Validation Metrics (Complete Unfiltered Portfolio)

| Executive Metric | Formula / Definition | Baseline Value | Status |
| :--- | :--- | :--- | :--- |
| **Total Sales (Revenue)** | $\sum \text{Sales}$ (Net revenue after discounts) | **$1,936,313.47** | Verified |
| **Total Profit** | $\sum \text{Profit}$ (Numeric equivalent to Gross/Net Profit) | **$593,390.69** | Verified |
| **Overall Profit Margin** | $(\sum \text{Profit} \div \sum \text{Sales}) \times 100$ | **30.65%** | Verified |
| **Total Orders** | Distinct Count of `Order ID` | **500 Orders** | Verified |
| **Average Order Value (AOV)** | $\text{Total Sales} \div \text{Total Orders}$ | **$3,872.63** | Verified |
| **Return Rate** | $(\text{Returned Orders} \div \text{Total Orders}) \times 100$ | **49.60%** (248 returns) | Verified |
| **Customer Base** | Distinct Count of `Customer ID` | **318 Customers** | Verified |
| **Average Discount** | Mean of `Discount %` | **7.62%** | Verified |

---

## 🔍 Data Quality Rules & Calculation Integrity

1. **Redundant Profit Columns**: In the source dataset, `Gross Profit` and `Net Profit` are numerically identical to `Profit` across all 500 rows ($0 discrepancy). Only `Profit` is utilized to avoid redundant or misleading metrics.
2. **Weighted Aggregate Margin**: Profit Margin % is strictly computed using the weighted formula $\frac{\sum \text{Profit}}{\sum \text{Sales}} \times 100$, rather than an arithmetic average of individual row percentages.
3. **Partial-Year 2025 Analytical Treatment**:
   - **2023**: 8 months of data (May 2023 – Dec 2023; Sales = $636.1K)
   - **2024**: 12 complete months (Jan 2024 – Dec 2024; Sales = $900.6K; +41.6% YoY growth)
   - **2025**: **Partial year through April 28, 2025** (4 months; Sales = $399.6K)
   - **Equivalent-Period YoY Comparison**: To prevent the false conclusion that business is slowing down in 2025, YoY comparisons evaluate the equivalent 4-month window:
     $$\text{Jan–Apr 2024: } \$213,983.42 \implies \text{Jan–Apr 2025: } \$399,564.93 \quad \mathbf{(+86.7\%\text{ surge})}$$
4. **Chronological Sorting**: Time series are grouped and sorted by `Year * 100 + MonthNo` (May-23, Jun-23, ... Apr-25), ensuring strict chronological ordering rather than alphabetical string sorting.
5. **Correlation vs. Causation**: Discount vs. Profit Margin scatter analysis computes the Pearson correlation coefficient ($r = -0.4635$), indicating moderate negative correlation without claiming pure causation.

---

## 📈 Dashboard Structure & Visualizations

The dashboard contains seven integrated visualization modules:

1. **Revenue & Profitability Trajectory Over Time (Chart 1)**:
   - Dual-axis combination chart (Bars = Sales Revenue, Line = Net Profit)
   - Granularity toggle: **Monthly** (24 months), **Quarterly** (8 quarters), and **Yearly** (3 years)
   - Visual annotations identifying the partial-year nature of 2025.
2. **Category Sales & Margin % (Chart 2)**:
   - Highlights that **Electronics** commands volume ($660.0K), but **Furniture** delivers the highest profit margin efficiency (**33.52%**).
3. **Regional Performance & Margins (Chart 3)**:
   - Compares Central, North, South, and West territories.
   - Shows **West** as the volume driver ($628.2K), while **North** attains the highest profit margin (**32.27%**).
4. **Brand Comparison (Chart 4)**:
   - Evaluates **Apple**, **Dell**, and **HP**.
   - Demonstrates that **Dell** outperforms on margin (**32.86%**), whereas Apple delivers a lower margin (**29.11%**).
5. **Top 10 Products & Sales Reps Ranking (Chart 5)**:
   - Horizontal bar chart with interactive toggle between **Top 10 Products** and **Top 10 Sales Representatives**.
   - SKU leader: Dell Laptop ($152.9K Sales, $47.9K Profit). Top Rep: Prakash ($91.5K Sales).
6. **Discount % vs. Profit Margin % Correlation (Chart 6)**:
   - Transaction-level scatter plot displaying every active transaction.
   - Dynamic trendline (linear regression $y = mx + b$) and Pearson correlation badge ($r = -0.4635$).
7. **Operational Health & Fulfillment Breakdown (Chart 7)**:
   - Donut charts with segmented tab toggles: **Order Status** (Completed, Shipped, Pending), **Payment Mode** (Credit Card, UPI, Cash), and **Return Status** (Yes vs. No).

---

## 🧠 Dynamic Key Business Insights Engine

The dashboard features 6 dynamic strategic cards that **recalculate live** whenever any filter is applied:
- **Growth Momentum**: Evaluates 2024 growth and calculates equivalent-period 2025 annualized trajectory.
- **Operational Risk Alert**: Flags the ~49.6% return rate and identifies which category suffers the highest return friction.
- **Profitability Mix Opportunity**: Recommends promotional shifts toward high-margin categories (Furniture, Accessories).
- **Brand Economics**: Recommends steering enterprise B2B purchasing toward Dell configurations and renegotiating vendor co-op allowances with Apple/HP.
- **Regional Expansion Upside**: Highlights the under-invested high-margin upside in the North region.
- **Pricing Policy Governance**: Recommends establishing an executive discount approval threshold for discounts $\ge 15\%$.

---

## 🎛️ Interactive Filters & Slicers

- **Global Search**: Substring matching across customer, product, rep, and geography.
- **Fiscal Year**: All, 2023, 2024, 2025 (flagged with partial-year indicator).
- **Quarter**: Multi-select pills (Q1, Q2, Q3, Q4).
- **Custom Date Range**: Date pickers with calendar validation (May 2023 – Apr 2025).
- **Region**: Multi-select (Central, North, South, West).
- **Category**: Multi-select (Accessories, Appliances, Electronics, Furniture, Stationery).
- **Brand**: Multi-select (Apple, Dell, HP).
- **Sales Representative**: Searchable dropdown supporting all 39 sales reps.
- **Order Status**: Multi-select (Completed, Shipped, Pending).
- **Return Status**: Segmented toggle (All, Retained No, Returned Yes).
- **Active Filter Scope Bar**: Live chips with 1-click removal and **Reset All Filters** button.
- **Zero-State Handling**: Friendly empty-state illustration if a combination returns 0 rows.

---

## 📋 Transaction Explorer & Audit Table

- Collapsible table with summary badges.
- Instant search bar and rows-per-page selector (10, 25, 50, 100 rows).
- Click-to-sort column headers (Ascending / Descending with arrow indicators).
- Status indicator pills (Completed, Shipped, Pending; Returned Yes/No).
- **Export Filtered to CSV** button generates an instant spreadsheet export of whatever records are currently filtered.

---

## 🎨 Enterprise UI/UX Features

- **Typography**: Inter (Google Fonts) with crisp tabular numeric styling.
- **Themes**: One-click **Dark Mode / Light Mode** toggle with `localStorage` memory and automatic Chart.js color palette adaptation.
- **Print & PDF Ready**: Dedicated `@media print` stylesheet that strips navigation and formats cards for presentation handouts.
- **Responsive Layout**: Adapts gracefully across desktop, laptop, tablet, and mobile displays with a slide-out filter drawer.
